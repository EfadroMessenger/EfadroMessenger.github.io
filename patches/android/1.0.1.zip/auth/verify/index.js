function normalizeServerUrl(raw, fallback) {
  let s = String(raw || "").trim().split(/\r?\n/)[0].trim().replace(/\/+$/, "");
  if (!s) s = fallback || "";
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) {
    const host = s.split("/")[0];
    const local = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
    s = (local ? "http://" : "https://") + s;
  }
  return s.replace(/\/+$/, "");
}

function resolveServerUrl() {
  const proto = location.protocol || "";
  const host = location.hostname || "";
  const base = (proto === "file:" || proto === "efadro:" || host === "app.efadro.local")
    ? "http://localhost:3000"
    : (location.origin || "").replace(/\/+$/, "");
  return fetch("../../serverip.txt", { cache: "no-store" })
    .then(r => (r.ok ? r.text() : ""))
    .then(t => {
      const final = normalizeServerUrl(t, base);
      localStorage.setItem("serverUrl", final);
      return final;
    })
    .catch(() => normalizeServerUrl(localStorage.getItem("serverUrl"), base));
}

const me = localStorage.getItem("myUsername") || "";
const info = document.getElementById("serverInfo");
resolveServerUrl().then(url => { if (info) info.textContent = "Server: " + url; });

function api(url, path, body) {
  return fetch(url + path, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Username": me },
    credentials: "include",
    body: JSON.stringify(body),
  }).then(r => r.json().then(d => ({ ok: r.ok, d })));
}

document.getElementById("mailForm").addEventListener("submit", e => {
  e.preventDefault();
  const err = document.getElementById("errorBox");
  err.classList.add("hidden");
  resolveServerUrl().then(url => api(url, "/api/email/resend", {
    email: document.getElementById("email").value.trim(),
  })).then(({ ok, d }) => {
    if (!ok) throw new Error((d && (d.detail || d.error)) || "Could not send");
    err.textContent = "Code sent. Check your inbox.";
    err.classList.remove("hidden");
  }).catch(e => {
    err.textContent = e.message;
    err.classList.remove("hidden");
  });
});

document.getElementById("codeForm").addEventListener("submit", e => {
  e.preventDefault();
  const err = document.getElementById("errorBox");
  err.classList.add("hidden");
  resolveServerUrl().then(url => api(url, "/api/email/verify", {
    code: document.getElementById("code").value.trim(),
  })).then(({ ok, d }) => {
    if (!ok) throw new Error(d.error || "Invalid code");
    location.href = "../../chat/";
  }).catch(e => {
    err.textContent = e.message;
    err.classList.remove("hidden");
  });
});

/* ============================================================
   Efadro Messenger — Chat app
   E2EE text (Web Crypto), encrypted files, WebRTC calls,
   roles/control panel, premium, settings — all client-side.
   ============================================================ */

/* ---------------- helpers ---------------- */
const $ = id => document.getElementById(id);
const ACCENT_COLORS = ["#0A84FF", "#30D158", "#FF9F0A", "#FF453A", "#BF5AF2", "#FF375F", "#5E5CE6", "#FFD60A"];
const AVATAR_COLORS = ["#0A84FF", "#30D158", "#FF9F0A", "#FF453A", "#BF5AF2", "#64D2FF", "#FFD60A", "#AC8E68", "#FF375F", "#5E5CE6"];
const MIME_EXT = { "image/jpeg": "jpg", "image/png": "png", "image/gif": "gif", "image/webp": "webp" };
const PERMISSION_LABELS = [
  ["send_messages", "send"], ["create_chats", "chats"], ["send_files", "files"],
  ["voice_video_calls", "calls"], ["delete_own_messages", "del own"],
  ["delete_any_messages", "del any"], ["edit_chats", "edit chats"],
  ["delete_chats", "del chats"], ["kick_users", "kick"], ["ban_users", "ban"],
  ["manage_users", "manage users"], ["manage_roles", "manage roles"],
  ["view_cp", "view CP"], ["manage_server", "server"], ["bot_api", "bot API"],
];

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------- player icons ---------- */
const PLAY_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
const PAUSE_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>';
const DL_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>';
const VOL_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
const MUTE_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M23 9l-6 6"/><path d="M17 9l6 6"/></svg>';
const FULL_SVG = '<svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>';

function fmtDur(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const s = Math.floor(sec);
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
}

function isNearBottom(el, margin = 100) {
  return el.scrollHeight - el.scrollTop - el.clientHeight < margin;
}

function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function formatBytes(n) {
  if (n == null) return "";
  if (n < 1024) return n + " B";
  if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
  if (n < 1073741824) return (n / 1048576).toFixed(1) + " MB";
  return (n / 1073741824).toFixed(2) + " GB";
}

function dateKey(ts) {
  const d = new Date(ts);
  return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
}

function isToday(ts) {
  return dateKey(ts) === dateKey(Date.now());
}

function dateLabel(ts) {
  const d = new Date(ts);
  const today = new Date();
  const yest = new Date(); yest.setDate(today.getDate() - 1);
  if (dateKey(ts) === dateKey(today.getTime())) return "Today";
  if (dateKey(ts) === dateKey(yest.getTime())) return "Yesterday";
  return d.toLocaleDateString([], { day: "numeric", month: "long", year: d.getFullYear() !== today.getFullYear() ? "numeric" : undefined });
}

function avatarColor(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

function initials(name) {
  return (name || "?").slice(0, 2).toUpperCase();
}

function avatarEl(name, avatar, cls) {
  const isColor = avatar && avatar.startsWith("#");
  const style = isColor ? `style="background:${avatar}"` : `style="background:${avatarColor(name)}"`;
  if (avatar && !isColor) {
    return `<div class="avatar ${cls || ""}" ${style}><img src="${escapeHtml(avatar)}" alt="" onerror="this.parentNode.textContent='${initials(name)}'"></div>`;
  }
  return `<div class="avatar ${cls || ""}" ${style}>${escapeHtml(initials(name))}</div>`;
}

function toast(msg, type = "info", ms = 3200) {
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = msg;
  $("toasts").appendChild(el);
  setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity .3s"; }, ms - 400);
  setTimeout(() => el.remove(), ms);
}

function showSystemNotification(title, body) {
  try {
    if (window.efadroNative && typeof window.efadroNative.notify === "function") {
      window.efadroNative.notify({ title, body });
      return;
    }
    if (!("Notification" in window)) return;
    if (Notification.permission === "granted") {
      new Notification(title, { body });
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission();
    }
  } catch (e) { /* noop */ }
}

/* ---------------- server url + socket.io loader ---------------- */
function normalizeServerUrl(raw, fallback) {
  let s = String(raw || "").trim().split(/\r?\n/)[0].trim().replace(/\/+$/, "");
  if (!s) s = fallback || "";
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) {
    const host = s.split("/")[0];
    const local = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
    s = (local ? "http://" : "https://") + s;
  }
  return s.replace(/\/+$/, "");
}

function uiOriginFallback() {
  const proto = location.protocol || "";
  const host = location.hostname || "";
  if (proto === "file:" || proto === "efadro:" || host === "app.efadro.local") {
    return "http://localhost:3000";
  }
  return (location.origin || "").replace(/\/+$/, "");
}

function resolveServerUrl() {
  /* The server address is ALWAYS read fresh from serverip.txt on every
     load — editing the file takes effect without clearing storage. */
  const base = uiOriginFallback();
  return fetch("../serverip.txt", { cache: "no-store" })
    .then(r => (r.ok ? r.text() : ""))
    .then(t => {
      const final = normalizeServerUrl(t, base);
      if (final !== localStorage.getItem("serverUrl")) {
        localStorage.setItem("serverUrl", final);
      }
      return final;
    })
    .catch(() => normalizeServerUrl(localStorage.getItem("serverUrl"), base));
}

function loadSocketIO(url) {
  // The Python backend does not serve the Socket.IO client script, so try in
  // order: 1) vendored copy next to this page (works everywhere),
  // 2) the server's own copy (Node-style backends), 3) public CDN.
  return new Promise((resolve, reject) => {
    if (window.io) return resolve(window.io);
    const candidates = [
      "socket.io.min.js",
      url + "/socket.io/socket.io.js",
      "https://cdn.socket.io/4.8.1/socket.io.min.js",
    ];
    let i = 0;
    const tryNext = () => {
      if (i >= candidates.length) {
        reject(new Error("Socket.IO client failed to load — is the backend running?"));
        return;
      }
      const src = candidates[i++];
      const s = document.createElement("script");
      s.src = src;
      s.onload = () => resolve(window.io);
      s.onerror = tryNext;
      document.head.appendChild(s);
    };
    tryNext();
  });
}

/* ---------------- API helper ---------------- */
let SERVER = "";
let fileToken = "";

async function api(method, path, body) {
  const opts = {
    method,
    headers: { "X-Username": localStorage.getItem("myUsername") || "" },
    credentials: "include",
  };
  if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(SERVER + path, opts);
  let data = null;
  try { data = await r.json(); } catch (e) { data = {}; }
  if (!r.ok) {
    const err = new Error((data && data.error) || ("HTTP " + r.status));
    err.status = r.status;
    err.data = data;
    throw err;
  }
  return data;
}

async function ensureFileToken() {
  if (fileToken) return fileToken;
  const d = await api("GET", "/api/files/token");
  fileToken = d.token;
  return fileToken;
}

function fileUrl(fileId, mime, name, dl) {
  const q = new URLSearchParams({
    mime: mime || "application/octet-stream",
    name: name || "efadro-file",
    user: localStorage.getItem("myUsername") || "",
    token: fileToken || "",
  });
  if (dl) q.set("dl", "1");
  return `${SERVER}/api/files/${fileId}?${q}`;
}

/* ---------------- state ---------------- */
const state = {
  me: localStorage.getItem("myUsername") || "",
  myDisplayName: localStorage.getItem("myDisplayName") || "",
  myRole: localStorage.getItem("myRole") || "user",
  permissions: JSON.parse(localStorage.getItem("myPermissions") || "[]"),
  chats: [],
  users: [],
  currentChat: null,
  socket: null,
  online: new Set(),
  typing: {},
  unread: {},
  keyCache: new Map(),
  encKey: null,
  userMatches: {},   // exact-username search hits (cache: lowercased q → user)
  searchSeq: 0,      // guards out-of-order search responses
  activeAudio: null, // currently playing custom audio element
  premiumActive: false,
  limits: { file_bytes: 2 * 1024 * 1024 * 1024, chats: 1000, stories_per_day: 4 },
  stories: [],
  storyPostedToday: 0,
};

function isPremium() {
  return !!state.premiumActive;
}

function maxFileBytes() {
  return (state.limits && state.limits.file_bytes) || (isPremium() ? 4 * 1024 * 1024 * 1024 : 2 * 1024 * 1024 * 1024);
}

const can = perm => state.permissions.includes(perm) || state.myRole === "owner";

/* ---------------- E2EE (client-side) ---------------- */
const e2ee = {
  KEY_NAME: "efadro-e2ee-keys",

  async ensureKeys() {
    const raw = localStorage.getItem(this.KEY_NAME);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        this.keys = parsed;
        return parsed;
      } catch (e) { /* fall through */ }
    }
    const kp = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
    // JWK is the only interoperable export format for ECDH private keys
    const privJwk = await crypto.subtle.exportKey("jwk", kp.privateKey);
    const pubRaw = await crypto.subtle.exportKey("raw", kp.publicKey);
    const keys = {
      priv: JSON.stringify(privJwk),
      pub: btoa(String.fromCharCode(...new Uint8Array(pubRaw))),
    };
    localStorage.setItem(this.KEY_NAME, JSON.stringify(keys));
    this.keys = keys;
    try {
      await api("POST", "/api/keys", { public_key: JSON.stringify({ alg: "ECDH", curve: "P-256", pub: keys.pub }) });
    } catch (e) { /* offline-safe */ }
    return keys;
  },

  async partnerPub(username) {
    const d = await api("GET", "/api/keys?users=" + encodeURIComponent(username));
    const raw = d.keys && d.keys[username];
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      return parsed.pub || parsed.publicKey || null;
    } catch (e) {
      return raw; // bare base64 fallback
    }
  },

  async ecdhShared(partnerPubB64) {
    const pubBytes = Uint8Array.from(atob(partnerPubB64), c => c.charCodeAt(0));
    const pubKey = await crypto.subtle.importKey("raw", pubBytes, { name: "ECDH", namedCurve: "P-256" }, false, []);
    const privJwk = JSON.parse(this.keys.priv);
    const privKey = await crypto.subtle.importKey("jwk", privJwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "ECDH", public: pubKey }, privKey, 256);
    return new Uint8Array(bits);
  },

  /* Derive the per-chat AES key.
     Direct chats: ECDH shared secret with the partner's public key.
     Groups/fallback: predictable salt (documented limitation — this is
     client-side obfuscation rather than true key exchange). */
  async deriveChatKey(chat) {
    const cached = state.keyCache.get(chat.uuid);
    if (cached) return cached;

    let material = null;
    if (chat.type === "usertouser" && chat.other_user) {
      const pub = await this.partnerPub(chat.other_user);
      if (pub) {
        try { material = await this.ecdhShared(pub); } catch (e) { material = null; }
      }
    }
    if (!material) {
      material = new TextEncoder().encode("efadro:" + chat.uuid);
    }
    const enc = new TextEncoder();
    const baseKey = await crypto.subtle.importKey("raw", material, "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt: enc.encode("efadro-chat-salt:" + chat.uuid), iterations: 100000, hash: "SHA-256" },
      baseKey, 256);
    const key = await crypto.subtle.importKey("raw", bits, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
    state.keyCache.set(chat.uuid, key);
    return key;
  },

  async encryptText(chat, text) {
    const key = await this.deriveChatKey(chat);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(text));
    return {
      ciphertext: btoa(String.fromCharCode(...new Uint8Array(ct))),
      iv: btoa(String.fromCharCode(...iv)),
      encrypted: true,
    };
  },

  async decryptText(chat, payload) {
    try {
      const key = await this.deriveChatKey(chat);
      const ct = Uint8Array.from(atob(payload.ciphertext), c => c.charCodeAt(0));
      const iv = Uint8Array.from(atob(payload.iv), c => c.charCodeAt(0));
      const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ct);
      return new TextDecoder().decode(pt);
    } catch (e) {
      return null;
    }
  },
};

/* ---------------- socket ---------------- */
function socketConnect(io) {
  const socket = io(SERVER, {
    transports: ["polling", "websocket"],
    withCredentials: true,
    secure: /^https:/i.test(SERVER),
  });
  state.socket = socket;

  socket.on("connect", () => {
    socket.emit("authenticate", { username: state.me });
    for (const c of state.chats) socket.emit("join_chat", { uuid: c.uuid });
  });

  socket.on("authenticated", d => {
    state.online = new Set(d.online || []);
    renderContacts();
    updateChatHeader();
  });

  socket.on("user_status", d => {
    if (d.status === "online") state.online.add(d.username);
    else state.online.delete(d.username);
    renderContacts();
    updateChatHeader();
    renderOnlineChips();
  });

  socket.on("new_message", msg => onNewMessage(msg));
  socket.on("poll_updated", msg => {
    const row = document.querySelector(`.msg-row[data-id="${msg.id}"]`);
    if (!row) return;
    const card = row.querySelector(".poll-card");
    if (card) card.outerHTML = pollHtml(msg);
  });

  socket.on("message_deleted", d => {
    const el = document.querySelector(`.msg-row[data-id="${d.id}"]`);
    if (el) el.remove();
    if (d.scope === "self") return; // only that user's view changed
    const chat = state.chats.find(c => c.uuid === d.chat_uuid);
    if (chat) {
      chat.last_message = null;
      refreshChatPreviews();
    }
  });

  socket.on("user_typing", d => {
    if (d.username === state.me) return;
    state.typing[d.uuid] = d.username;
    clearTimeout(state.typing[d.uuid + "_t"]);
    state.typing[d.uuid + "_t"] = setTimeout(() => { delete state.typing[d.uuid]; updateChatHeader(); }, 2500);
    updateChatHeader();
    renderContacts();
  });

  socket.on("chat_created", chat => { void chat; loadChats(); });
  socket.on("chat_deleted", d => {
    if (state.currentChat && state.currentChat.uuid === d.uuid) {
      setCurrentChat(null);
    }
    state.chats = state.chats.filter(c => c.uuid !== d.uuid);
    renderContacts();
    socket.emit("leave_chat", { uuid: d.uuid });
  });

  socket.on("profile_updated", d => {
    const chat = state.chats.find(c => c.other_user === d.username);
    if (chat) chat.other_profile = d.profile;
    renderContacts();
    updateChatHeader();
  });

  socket.on("role_updated", d => {
    if (d.username === state.me || d.username === "*") {
      refreshMe();
    }
    if (state.currentChat) loadChatInfo();
    toast("Your permissions were updated by an administrator.", "info");
  });

  socket.on("system_broadcast", d => {
    const banner = $("broadcastBanner");
    $("broadcastTextBanner").textContent = "📢 " + (d.text || "");
    banner.classList.remove("hidden");
    showSystemNotification("Efadro broadcast", d.text);
    setTimeout(() => banner.classList.add("hidden"), 20000);
  });

  socket.on("force_disconnect", d => {
    toast("Session ended: " + (d.reason || "disconnected"), "error");
    setTimeout(doLogout, 1500);
  });
  socket.on("incoming_call", d => onIncomingCall(d));
  socket.on("call_accepted", d => onCallAccepted(d));
  socket.on("call_rejected", d => onCallRejected(d));
  socket.on("ice_candidate", d => onIceCandidate(d));
  socket.on("call_ended", d => onCallEnded(d));
  socket.on("call_ringing", d => { if (d.call_id === state.call?.callId) setCallState("ringing"); });
  socket.on("chat_activity", () => { /* presence-driven; nothing needed */ });

  socket.on("story_posted", () => { loadStories(); });
  socket.on("story_deleted", () => { loadStories(); });

  socket.on("error", d => {
    if (d && d.error) toast(String(d.error), "error");
  });
  socket.on("disconnect", () => { /* reconnection handled by socket.io */ });
}

/* ---------------- data loading ---------------- */
async function loadChats() {
  try {
    const chats = await api("GET", "/api/chats");
    state.chats = chats;
    renderContacts();
    for (const c of chats) state.socket && state.socket.emit("join_chat", { uuid: c.uuid });
  } catch (e) {
    if (e.status === 401) doLogout();
  }
}

async function refreshMe() {
  try {
    const me = await api("GET", "/api/me");
    state.myRole = me.role;
    state.permissions = me.permissions || [];
    state.myDisplayName = (me.profile && me.profile.display_name) || state.me;
    localStorage.setItem("myRole", me.role);
    localStorage.setItem("myPermissions", JSON.stringify(state.permissions));
    localStorage.setItem("myDisplayName", state.myDisplayName);
    if (me.profile && me.profile.avatar) localStorage.setItem("myAvatar", me.profile.avatar);
    if (me.premium) state.premiumActive = !!me.premium.active;
    if (me.limits) state.limits = me.limits;
    updateSidebarUser();
    toggleCpButton();
    renderContacts();
  } catch (e) { /* ignore */ }
}

function updateSidebarUser() {
  const name = $("sidebarUserName");
  if (name) name.textContent = state.myDisplayName || state.me;
  const role = $("sidebarUserRole");
  if (role) role.textContent = state.myRole;
  const av = $("sidebarUserAvatar");
  if (av) {
    const avatar = localStorage.getItem("myAvatar") || "";
    const isColor = avatar && avatar.startsWith("#");
    av.style.background = isColor ? avatar : avatarColor(state.me);
    av.innerHTML = (avatar && !isColor) ? `<img src="${escapeHtml(avatar)}" alt="">` : escapeHtml(initials(state.me));
  }
}

/* ---------------- contacts ---------------- */
function chatTitle(chat) {
  if (chat.type === "usertouser") return (chat.other_profile && chat.other_profile.display_name) || chat.other_user || chat.name;
  return chat.name;
}

function chatPreview(chat) {
  const lm = chat.last_message;
  if (!lm) return "No messages yet";
  const mine = lm.sender === state.me;
  const prefix = mine ? "" : (chat.type !== "usertouser" ? lm.sender + ": " : "");
  if (lm.type === "text") {
    const p = lm.payload || {};
    if (p.encrypted) return (mine ? "You: " : prefix) + "🔒 Encrypted message";
    return (mine ? "You: " : prefix) + (p.text || "");
  }
  const names = { file: "📄 File", image: "🖼 Image", audio: "🎵 Audio", video: "🎬 Video" };
  return (mine ? "You: " : prefix) + (names[lm.type] || lm.type);
}

function renderContacts() {
  const list = $("contactsList");
  const q = ($("searchInput").value || "").trim().toLowerCase();
  let chats = state.chats.slice();
  if (q) chats = chats.filter(c => chatTitle(c).toLowerCase().includes(q));

  // Global user search: typing a full username reveals that user,
  // even if they aren't in any chat yet.
  let userRow = "";
  const hit = q ? state.userMatches[q] : null;
  if (hit && hit.username !== state.me &&
      !state.chats.some(c => c.type === "usertouser" && c.members.includes(hit.username) && c.members.includes(state.me))) {
    userRow = `
      <div class="contact user-result" data-action="new-direct" data-user="${escapeHtml(hit.username)}">
        <div class="contact-avatar-wrap">${avatarEl(hit.username, hit.avatar)}</div>
        <div class="contact-body">
          <div class="contact-name">${escapeHtml(hit.display_name || hit.username)}</div>
          <div class="contact-preview">@${escapeHtml(hit.username)} — start direct chat</div>
        </div>
        <span class="user-result-plus">+</span>
      </div>`;
  }

  if (!chats.length && !userRow) {
    list.innerHTML = `<div class="contact" style="color:var(--text-secondary);font-size:13px;justify-content:center;cursor:default">${
      q ? "No matching chats or users" : "No conversations yet"}</div>`;
    return;
  }

  list.innerHTML = userRow + chats.map(c => {
    const title = chatTitle(c);
    const avatar = c.type === "usertouser" && c.other_profile ? c.other_profile.avatar : "";
    const online = c.type === "usertouser" && c.other_user && state.online.has(c.other_user);
    const typingName = state.typing[c.uuid];
    const unread = state.unread[c.uuid] || 0;
    return `
      <div class="contact ${state.currentChat && state.currentChat.uuid === c.uuid ? "active" : ""}" data-uuid="${c.uuid}">
        <div class="contact-avatar-wrap">
          ${avatarEl(c.type === "usertouser" ? (c.other_user || title) : title, avatar)}
          ${c.type === "usertouser" ? `<span class="online-dot ${online ? "" : "hidden"}"></span>` : ""}
        </div>
        <div class="contact-body">
          <div class="contact-top">
            <div class="contact-name">${escapeHtml(title)}</div>
            <div class="contact-time">${c.last_message ? formatTime(c.last_message.timestamp) : ""}</div>
          </div>
          <div class="contact-preview ${c.last_message && c.last_message.sender === state.me ? "mine" : ""}">
            ${typingName ? `<span style="color:var(--accent);font-style:italic">typing…</span>` : escapeHtml(chatPreview(c))}
          </div>
        </div>
        ${unread ? `<span class="contact-badge">${unread}</span>` : ""}
      </div>`;
  }).join("");

  list.querySelectorAll(".contact").forEach(el => {
    el.addEventListener("click", () => {
      if (el.dataset.action === "new-direct") {
        openOrCreateDirect(el.dataset.user);
        return;
      }
      openChat(el.dataset.uuid);
    });
  });
}

/* Start (or reopen) a direct chat with an exact-username search hit. */
async function openOrCreateDirect(username) {
  if (!username || username === state.me) return;
  const existing = state.chats.find(c => c.type === "usertouser" &&
    c.members.includes(username) && c.members.includes(state.me));
  if (existing) {
    await openChat(existing.uuid);
    return;
  }
  if (!can("create_chats")) { toast("Permission denied: create_chats", "error"); return; }
  try {
    const chat = await api("POST", "/api/createchat", { type: "usertouser", users: [username] });
    await loadChats();
    await openChat(chat.uuid);
    $("searchInput").value = "";
    renderContacts();
    $("messageInput").focus();
  } catch (e) {
    toast(e.message, "error");
  }
}

function refreshChatPreviews() {
  renderContacts();
  updateChatHeader();
}

/* ---------------- chat open / render ---------------- */
async function openChat(uuid) {
  const chat = state.chats.find(c => c.uuid === uuid);
  if (!chat) return;
  setCurrentChat(chat);
  delete state.unread[uuid];
  renderContacts();

  const msgs = await api("GET", `/api/chats/${uuid}/messages`);
  if (state.currentChat && state.currentChat.uuid === uuid) {
    renderMessages(msgs);
  }
  const c = state.chats.find(x => x.uuid === uuid);
  if (c) { c.last_message = msgs.length ? msgs[msgs.length - 1] : null; }
  renderContacts();
  $("messageInput").focus();
}

/* The composer bar is always visible at the bottom; it is simply
   disabled until a chat is opened. */
function setComposerState() {
  const has = !!state.currentChat;
  const input = $("messageInput");
  input.disabled = !has;
  input.placeholder = has ? "Message…" : "Select a chat to start messaging";
  $("composer").classList.toggle("disabled", !has);
  ["attachBtn", "emojiBtn"].forEach(id => { $(id).disabled = !has; });
  if (!has) {
    $("sendBtn").classList.add("hidden");
    $("attachMenu").classList.add("hidden");
    toggleEmojiPicker(false);
  }
}

function setCurrentChat(chat) {
  state.currentChat = chat;
  $("emptyState").classList.toggle("hidden", !!chat);
  $("chatView").classList.toggle("hidden", !chat);
  document.documentElement.classList.toggle("chat-open", !!chat);
  if (isMobileUi()) closeDrawer();
  setComposerState();
  updateChatHeader();
  if (!chat) {
    $("jumpBottom").classList.add("hidden");
    return;
  }
  const isDirect = chat.type === "usertouser";
  const name = isDirect ? (chat.other_user || chat.name) : chat.name;
  const avatar = isDirect && chat.other_profile ? chat.other_profile.avatar : "";
  const isColor = avatar && avatar.startsWith("#");
  const bg = isColor ? avatar : avatarColor(name);
  $("chatAvatar").innerHTML = (avatar && !isColor)
    ? `<img src="${escapeHtml(avatar)}" alt="">`
    : escapeHtml(initials(name));
  $("chatAvatar").style.background = bg;
  $("chatName").textContent = chatTitle(chat);
  $("callVoiceBtn").style.display = isDirect ? "" : "none";
  $("callVideoBtn").style.display = isDirect ? "" : "none";
  updateChatHeader();
}

function updateChatHeader() {
  if (!state.currentChat) return;
  const chat = state.currentChat;
  const typing = state.typing[chat.uuid];
  if (typing) {
    $("chatMeta").textContent = typing + " is typing…";
    $("chatMeta").classList.add("typing");
    return;
  }
  $("chatMeta").classList.remove("typing");
  if (chat.type === "usertouser") {
    const online = state.online.has(chat.other_user);
    $("chatMeta").textContent = online ? "● Online" : "Offline";
  } else {
    $("chatMeta").textContent = chat.members ? chat.members.length + " members" : "";
  }
}

function renderMessages(msgs) {
  const list = $("messagesList");
  list.innerHTML = "";
  let lastDate = null;
  let lastSender = null;

  const els = [];
  for (const m of msgs) {
    const dk = dateKey(m.timestamp);
    // no "Today" separators — today's messages flow without a date label
    if (dk !== lastDate && !isToday(m.timestamp)) {
      els.push(`<div class="date-sep" data-date="${dk}">${escapeHtml(dateLabel(m.timestamp))}</div>`);
      lastDate = dk;
      lastSender = null;
    }
    const grouped = m.sender === lastSender;
    els.push(messageHtml(m, grouped));
    lastSender = m.sender;
  }
  list.innerHTML = els.join("");

  // decrypt text bubbles + render Telegram-style emoji
  for (const m of msgs) {
    if (m.type === "text" && m.payload && m.payload.encrypted) {
      decryptBubble(m);
    }
  }
  renderAllEmoji(list);
  wireMediaPlayers(list);
  updateJumpButton();

  // The chat opens at the END of the conversation.
  scrollToBottom(list, true);
  // Images load async → re-stick to the bottom once they arrive.
  list.querySelectorAll("img").forEach(img => {
    img.addEventListener("load", () => {
      if (state.currentChat && isNearBottom(list)) list.scrollTop = list.scrollHeight;
    });
    img.addEventListener("error", () => {
      if (state.currentChat && isNearBottom(list)) list.scrollTop = list.scrollHeight;
    });
  });
}

function scrollToBottom(el, force) {
  if (!el) return;
  if (force || isNearBottom(el)) el.scrollTop = el.scrollHeight;
  requestAnimationFrame(() => {
    if (force || isNearBottom(el)) el.scrollTop = el.scrollHeight;
  });
}

/* Parse every message bubble with Twemoji (Telegram-style rendering).
   Emoji-only messages become large "sticker-like" bubbles. */
function renderAllEmoji(root) {
  if (!root) return;
  root.querySelectorAll(".bubble-text").forEach(b => {
    const row = b.closest(".msg-row");
    const isEmojiOnly = row && row.classList.contains("emoji-only");
    if (isEmojiOnly) {
      // Telegram style: render emoji-only messages extra large.
      // One wrapper span keeps ZWJ sequences intact for Twemoji parsing.
      b.innerHTML = `<span class="big-emoji">${escapeHtml(b.textContent)}</span>`;
    }
    renderEmoji(b);
  });
}

function decryptBubble(m) {
  const bubble = document.querySelector(`.msg-row[data-id="${m.id}"] .bubble-text`);
  if (!bubble || !state.currentChat) return;
  bubble.innerHTML = `<span style="opacity:.65">🔒 Decrypting…</span>`;
  e2ee.decryptText(state.currentChat, m.payload).then(text => {
    if (text === null) {
      bubble.textContent = "🔒 Unable to decrypt this message";
      bubble.style.opacity = ".6";
    } else {
      bubble.textContent = text;
      const row = bubble.closest(".msg-row");
      if (row && hasOnlyEmoji(text)) {
        row.classList.add("emoji-only");
        bubble.innerHTML = `<span class="big-emoji">${escapeHtml(text)}</span>`;
      }
      renderEmoji(bubble);
    }
  });
}

function messageHtml(m, grouped) {
  const mine = m.sender === state.me;
  const cls = ["msg-row", mine ? "mine" : "theirs"];
  if (grouped) cls.push("grouped");

  let body = "";
  if (m.type === "text") {
    const p = m.payload || {};
    if (p.encrypted) {
      body = `<div class="bubble bubble-text"><span style="opacity:.65">🔒 …</span></div>`;
    } else {
      const text = p.text || "";
      const emojiOnly = text && hasOnlyEmoji(text);
      if (emojiOnly) cls.push("emoji-only");
      body = `<div class="bubble bubble-text${emojiOnly ? " big-emoji-bubble" : ""}">${escapeHtml(text)}</div>`;
    }
  } else if (m.type === "image") {
    const p = m.payload || {};
    const url = m.file_id ? fileUrl(m.file_id, p.mime || "image/jpeg", p.name || "image.jpg") : "";
    body = `<div class="bubble msg-image">
      <img src="${escapeHtml(url)}" alt="image" loading="lazy" data-src="${escapeHtml(url)}" data-name="${escapeHtml(p.name || "image")}" data-mime="${escapeHtml(p.mime || "image/jpeg")}" data-fid="${escapeHtml(m.file_id || "")}">
    </div>`;
  } else if (m.type === "file") {
    const p = m.payload || {};
    const url = m.file_id ? fileUrl(m.file_id, p.mime || "application/octet-stream", p.name || "file", true) : "#";
    body = `<div class="bubble">
      <div class="file-card">
        <div class="file-icon"><svg class="svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></div>
        <div class="file-info">
          <div class="file-name">${escapeHtml(p.name || "file")}</div>
          <div class="file-size">${escapeHtml(formatBytes(p.size))}</div>
        </div>
        <a class="file-dl" href="${escapeHtml(url)}" download="${escapeHtml(p.name || "file")}" title="Download"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg></a>
      </div>
    </div>`;
  } else if (m.type === "audio" || m.type === "video") {
    const p = m.payload || {};
    const url = m.file_id ? fileUrl(m.file_id, p.mime || (m.type === "audio" ? "audio/mpeg" : "video/mp4"), p.name || (m.type + ".bin")) : "";
    const isAudio = m.type === "audio";
    const chatTitleHere = state.currentChat ? chatTitle(state.currentChat) : "";
    body = isAudio ? audioPlayerHtml(url, p, chatTitleHere) : videoPlayerHtml(url, p);
  } else if (m.type === "sticker") {
    const p = m.payload || {};
    body = `<div class="bubble" style="background:transparent;box-shadow:none;padding:4px"><img src="stickers/${escapeHtml(p.file || "smile.svg")}" alt="${escapeHtml(p.emoji || "")}" width="132" height="132"></div>`;
  } else {
    body = `<div class="bubble">${escapeHtml(JSON.stringify(m.payload || {}))}</div>`;
  }
  const reply = (m.payload && m.payload.reply) || null;
  if (reply) {
    body = `<div class="msg-reply"><b>${escapeHtml(reply.sender)}</b> · ${escapeHtml(reply.preview || reply.type || "")}</div>` + body;
  }

  // every user may delete-for-me any message; 'for everyone' needs the right
  // to delete this message for everyone
  const canDelEveryone = mine || can("delete_any_messages");
  const actions = `<div class="msg-actions">
        <button data-act="reply" title="Reply">↩</button>
        <button data-act="delete" title="Delete"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
        <div class="del-menu hidden">
          <button data-act="del-self">Delete for me</button>
          ${canDelEveryone ? '<button data-act="del-everyone">Delete for everyone</button>' : ""}
        </div>
      </div>`;

  const time = `<div class="msg-time">${formatTime(m.timestamp)}${mine ? '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>' : ""}</div>`;

  return `<div class="${cls.join(" ")}" data-id="${m.id}" data-sender="${escapeHtml(m.sender)}" data-chat="${escapeHtml(m.chat_uuid)}">
    <div class="msg-stack">
      ${!mine && !grouped && state.currentChat && state.currentChat.type !== "usertouser" ? `<div class="msg-sender">${escapeHtml(m.sender)}</div>` : ""}
      <div style="position:relative">
        ${actions}
        ${body}
        ${time}
      </div>
    </div>
  </div>`;
}

/* ---------------- custom media players ---------------- */
function audioPlayerHtml(url, p, chatTitleHere) {
  return `<div class="bubble media-player">
    <div class="media-name">${escapeHtml(p.name || "audio")}</div>
    <div class="audio-player" data-url="${escapeHtml(url)}" data-name="${escapeHtml(p.name || "audio")}" data-chat="${escapeHtml(chatTitleHere || "")}">
      <button class="ap-btn" data-act="toggle" title="Play / pause">${PLAY_SVG}</button>
      <div class="ap-main">
        <input type="range" class="ap-seek" min="0" max="1000" value="0" step="1" title="Seek">
        <span class="ap-time">0:00 / 0:00</span>
      </div>
      <button class="ap-btn ap-dl" data-act="download" title="Download">${DL_SVG}</button>
    </div>
    <div class="media-size">${escapeHtml(formatBytes(p.size))}</div>
  </div>`;
}

function videoPlayerHtml(url, p) {
  return `<div class="bubble media-player">
    <div class="media-name">${escapeHtml(p.name || "video")}</div>
    <div class="video-player" data-url="${escapeHtml(url)}">
      <video preload="metadata" playsinline></video>
      <div class="vp-bigplay">
        <button class="icon-btn" data-act="bigplay" title="Play"><svg class="svg-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button>
      </div>
      <div class="vp-controls">
        <button class="vp-btn" data-act="toggle" title="Play / pause">${PLAY_SVG}</button>
        <input type="range" class="vp-seek" min="0" max="1000" value="0" step="1" title="Seek">
        <span class="vp-time">0:00 / 0:00</span>
        <button class="vp-btn" data-act="mute" title="Mute">${VOL_SVG}</button>
        <button class="vp-btn" data-act="full" title="Fullscreen">${FULL_SVG}</button>
      </div>
    </div>
    <div class="media-size">${escapeHtml(formatBytes(p.size))}</div>
  </div>`;
}

function wireMediaPlayers(root) {
  if (!root) return;
  root.querySelectorAll(".audio-player").forEach(wireAudioPlayer);
  root.querySelectorAll(".video-player").forEach(wireVideoPlayer);
}

function wireAudioPlayer(container) {
  const url = container.dataset.url;
  const name = container.dataset.name || "audio";
  const sub = container.dataset.chat || "";
  const audio = new Audio(url);
  audio.preload = "metadata";
  audio.className = "efadro-audio";
  container._audio = audio;

  const btn = container.querySelector('[data-act="toggle"]');
  const seek = container.querySelector(".ap-seek");
  const timeEl = container.querySelector(".ap-time");
  const dl = container.querySelector('[data-act="download"]');

  audio.addEventListener("loadedmetadata", () => {
    timeEl.textContent = "0:00 / " + fmtDur(audio.duration);
  });
  audio.addEventListener("timeupdate", () => {
    if (!container._seeking && audio.duration) {
      seek.value = Math.round(audio.currentTime / audio.duration * 1000);
    }
    timeEl.textContent = fmtDur(audio.currentTime) + " / " + fmtDur(audio.duration);
  });
  audio.addEventListener("play", () => { btn.innerHTML = PAUSE_SVG; syncNp(); });
  audio.addEventListener("pause", () => { btn.innerHTML = PLAY_SVG; syncNp(); });
  audio.addEventListener("ended", () => { seek.value = 0; });

  btn.addEventListener("click", e => {
    e.stopPropagation();
    if (audio.paused) playAudio(audio, name, sub);
    else audio.pause();
  });
  seek.addEventListener("input", () => {
    container._seeking = true;
    if (audio.duration) audio.currentTime = seek.value / 1000 * audio.duration;
  });
  seek.addEventListener("change", () => { container._seeking = false; });
  if (dl) {
    dl.addEventListener("click", e => {
      e.stopPropagation();
      window.open(url, "_blank");
    });
  }
}

function playAudio(audio, name, sub) {
  // one audio at a time; stop any playing video as well
  document.querySelectorAll("audio.efadro-audio").forEach(a => { if (a !== audio) a.pause(); });
  const v = document.querySelector("video.efadro-video");
  if (v && !v.paused) v.pause();
  audio.play().catch(() => {});
  state.activeAudio = audio;
  $("npTitle").textContent = name;
  $("npSub").textContent = sub || "";
  $("nowPlaying").classList.remove("hidden");
  syncNp();
}

function syncNp() {
  const a = state.activeAudio;
  const btn = $("npToggle");
  if (!btn || !a) return;
  btn.innerHTML = a.paused ? PLAY_SVG : PAUSE_SVG;
  btn.innerHTML = btn.innerHTML.replace("svg-icon-small", "svg-icon");
}

function wireVideoPlayer(container) {
  const url = container.dataset.url;
  const video = container.querySelector("video");
  video.src = url;
  video.className = "efadro-video";

  const big = container.querySelector(".vp-bigplay");
  const btn = container.querySelector('[data-act="toggle"]');
  const seek = container.querySelector(".vp-seek");
  const timeEl = container.querySelector(".vp-time");
  const muteBtn = container.querySelector('[data-act="mute"]');
  const fullBtn = container.querySelector('[data-act="full"]');
  container.classList.add("paused");

  video.addEventListener("loadedmetadata", () => {
    timeEl.textContent = "0:00 / " + fmtDur(video.duration);
  });
  video.addEventListener("timeupdate", () => {
    if (!container._seeking && video.duration) {
      seek.value = Math.round(video.currentTime / video.duration * 1000);
    }
    timeEl.textContent = fmtDur(video.currentTime) + " / " + fmtDur(video.duration);
  });
  video.addEventListener("play", () => {
    btn.innerHTML = PAUSE_SVG;
    big.classList.add("hidden");
    container.classList.remove("paused");
    document.querySelectorAll("audio.efadro-audio").forEach(a => a.pause());
  });
  video.addEventListener("pause", () => {
    btn.innerHTML = PLAY_SVG;
    big.classList.remove("hidden");
    container.classList.add("paused");
  });
  video.addEventListener("ended", () => { seek.value = 0; });

  const toggle = () => {
    if (video.paused) video.play().catch(() => {});
    else video.pause();
  };
  btn.addEventListener("click", e => { e.stopPropagation(); toggle(); });
  big.addEventListener("click", e => { e.stopPropagation(); toggle(); });
  container.addEventListener("click", e => {
    if (e.target.closest(".vp-controls")) return;
    toggle();
  });
  seek.addEventListener("input", () => {
    container._seeking = true;
    if (video.duration) video.currentTime = seek.value / 1000 * video.duration;
  });
  seek.addEventListener("change", () => { container._seeking = false; });
  muteBtn.addEventListener("click", e => {
    e.stopPropagation();
    video.muted = !video.muted;
    muteBtn.innerHTML = video.muted ? MUTE_SVG : VOL_SVG;
  });
  fullBtn.addEventListener("click", e => {
    e.stopPropagation();
    if (document.fullscreenElement) document.exitFullscreen();
    else if (container.requestFullscreen) container.requestFullscreen();
  });
}

/* ---------------- sending ---------------- */
async function sendText() {
  const input = $("messageInput");
  const text = input.value;
  if (!text.trim() || !state.currentChat) return;
  if (!can("send_messages")) { toast("You don't have permission to send messages", "error"); return; }
  input.value = "";
  input.focus();

  const chat = state.currentChat;
  try {
    const payload = await e2ee.encryptText(chat, text);
    if (replyTo) payload.reply_to = replyTo.id;
    const msg = await api("POST", "/api/send", { uuid: chat.uuid, type: "text", payload });
    clearReply();
    appendMessageLocal(msg);
  } catch (e) {
    toast(e.message || "Failed to send", "error");
  }
}

async function sendFile(kind, file) {
  if (!state.currentChat) return;
  if (!can("send_files")) { toast("You don't have permission to send files", "error"); return; }
  const cap = maxFileBytes();
  if (file.size > cap) {
    const gb = Math.round(cap / (1024 * 1024 * 1024));
    toast("Max file size is " + gb + " GB" + (isPremium() ? "." : ". Premium allows 4 GB."), "error");
    return;
  }

  const uploading = toastEl("Uploading " + file.name + "…");
  try {
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch(SERVER + "/api/upload", {
      method: "POST",
      headers: { "X-Username": state.me },
      credentials: "include",
      body: fd,
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "upload failed");
    uploading.remove();

    const mime = file.type || "application/octet-stream";
    const msg = await api("POST", "/api/send", {
      uuid: state.currentChat.uuid,
      type: kind,
      payload: { name: file.name, mime, size: file.size },
      file_id: d.file_id,
    });
    appendMessageLocal(msg);
  } catch (e) {
    uploading.remove();
    toast(e.message || "Upload failed", "error");
  }
}

function toastEl(text) {
  const el = document.createElement("div");
  el.className = "toast info";
  el.textContent = text;
  $("toasts").appendChild(el);
  return el;
}

function appendMessageLocal(msg) {
  if (document.querySelector(`.msg-row[data-id="${msg.id}"]`)) return; // dedupe REST + socket echo
  if (state.currentChat && state.currentChat.uuid === msg.chat_uuid) {
    const list = $("messagesList");
    const lastDate = list.querySelector(".date-sep:last-of-type");
    const prev = list.querySelector(".msg-row:last-of-type");
    const prevSender = prev ? prev.dataset.sender : null;
    let html = "";
    if ((!lastDate || lastDate.dataset.date !== dateKey(msg.timestamp)) && !isToday(msg.timestamp)) {
      html += `<div class="date-sep" data-date="${dateKey(msg.timestamp)}">${escapeHtml(dateLabel(msg.timestamp))}</div>`;
    }
    const grouped = prevSender === msg.sender;
    const stick = msg.sender === state.me || isNearBottom(list);
    list.insertAdjacentHTML("beforeend", html + messageHtml(msg, grouped));
    const freshRow = list.querySelector(`.msg-row[data-id="${msg.id}"]`);
    if (freshRow) {
      if (msg.type === "text" && msg.payload && msg.payload.encrypted) decryptBubble(msg);
      const fresh = freshRow.querySelector(".bubble-text");
      if (fresh) renderAllEmoji(fresh);
      wireMediaPlayers(freshRow);
      freshRow.querySelectorAll("img").forEach(img => {
        img.addEventListener("load", () => { if (state.currentChat && isNearBottom(list)) list.scrollTop = list.scrollHeight; });
      });
    }
    if (stick) scrollToBottom(list);
    updateJumpButton();
  }
  const chat = state.chats.find(c => c.uuid === msg.chat_uuid);
  if (chat) {
    chat.last_message = msg;
    if (!state.currentChat || state.currentChat.uuid !== msg.chat_uuid) {
      state.unread[msg.chat_uuid] = (state.unread[msg.chat_uuid] || 0) + 1;
    }
  }
  renderContacts();
  updateChatHeader();
}

function onNewMessage(msg) {
  appendMessageLocal(msg);
  const chat = state.chats.find(c => c.uuid === msg.chat_uuid);
  if (chat && (!state.currentChat || state.currentChat.uuid !== msg.chat_uuid)) {
    showSystemNotification(chatTitle(chat), msg.type === "text" ? "🔒 New encrypted message" : "New " + msg.type);
  }
}

/* ---------------- typing ---------------- */
let typingTimeout = null;
function emitTyping() {
  if (!state.currentChat || !state.socket) return;
  state.socket.emit("typing", { uuid: state.currentChat.uuid });
}

/* ---------------- image lightbox ---------------- */
/* custom picture viewer: fit to screen, zoom, pan, download */
let lbZoomFactor = 1;
let lbFitZoom = 1;
let lbNatural = { w: 0, h: 0 };

function openLightbox(url, name) {
  const img = $("lbImage");
  img.style.width = ""; img.style.height = "";
  lbZoomFactor = 1;
  img.onload = () => {
    lbNatural = { w: img.naturalWidth || 0, h: img.naturalHeight || 0 };
    $("lbRes").textContent = lbNatural.w + " × " + lbNatural.h + " px";
    const stage = $("lbStage");
    lbFitZoom = Math.max(0.01, Math.min(
      1,
      (stage.clientWidth - 24) / (lbNatural.w || 1),
      (stage.clientHeight - 24) / (lbNatural.h || 1)
    ));
    applyLbZoom();
    $("lbStage").scrollTop = 0;
    $("lbStage").scrollLeft = 0;
  };
  img.src = url;
  $("lbDownload").href = url;
  $("lbDownload").setAttribute("download", name || "image");
  $("lightbox").classList.remove("hidden");
}

function applyLbZoom() {
  const img = $("lbImage");
  const z = lbFitZoom * lbZoomFactor;
  img.style.width = Math.max(1, Math.round((lbNatural.w || 1) * z)) + "px";
  img.style.height = Math.max(1, Math.round((lbNatural.h || 1) * z)) + "px";
  $("lbZoomPct").textContent = Math.round(lbZoomFactor * 100) + "%";
}

function zoomLb(delta) {
  lbZoomFactor = Math.min(8, Math.max(1, Math.round((lbZoomFactor + delta) * 4) / 4));
  applyLbZoom();
}

/* ---------------- now playing ---------------- */
function updateJumpButton() {
  const list = $("messagesList");
  $("jumpBottom").classList.toggle("hidden", !state.currentChat || isNearBottom(list));
}

/* ---------------- calls (WebRTC) ---------------- */
const call = {
  pc: null,
  localStream: null,
  callId: null,
  type: "voice",
  peer: null,
  isCaller: false,
  timer: null,
  seconds: 0,
  ring: null,
};

function setCallState(text) { $("callState").textContent = text; }

function startRinging() {
  try {
    const ctx = call.ctx || (call.ctx = new (window.AudioContext || window.webkitAudioContext)());
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 640;
    gain.gain.value = 0.12;
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    call.ringOsc = osc;
    call.ringGain = gain;
    call.ring = setInterval(() => {
      gain.gain.value = gain.gain.value > 0.05 ? 0 : 0.12;
    }, 550);
  } catch (e) { /* no audio */ }
}

function stopRinging() {
  if (call.ring) clearInterval(call.ring);
  if (call.ringOsc) { try { call.ringOsc.stop(); } catch (e) {} }
  call.ring = null; call.ringOsc = null;
}

async function getUserMediaForCall(type) {
  return navigator.mediaDevices.getUserMedia({
    audio: true,
    video: type === "video" ? { width: { ideal: 1280 }, height: { ideal: 720 } } : false,
  });
}

function showCallOverlay(peer, type, isCaller) {
  $("callOverlay").classList.remove("hidden");
  $("incomingCall").classList.add("hidden");
  $("callName").textContent = peer;
  $("callAvatar").innerHTML = `<div class="call-avatar" style="width:100%;height:100%;border-radius:50%;background:${avatarColor(peer)};display:flex;align-items:center;justify-content:center;font-size:38px">${escapeHtml(initials(peer))}</div>`.replace("call-avatar", "");
  $("callState").textContent = isCaller ? "Calling…" : "Connecting…";
  $("callTimer").classList.add("hidden");
  $("remoteVideo").style.display = "none";
  call.type = type;
  call.peer = peer;
  call.isCaller = isCaller;
}

function hideCallOverlay() {
  $("callOverlay").classList.add("hidden");
  $("incomingCall").classList.add("hidden");
  if (call.timer) clearInterval(call.timer);
  call.timer = null;
  if (call.pc) { try { call.pc.close(); } catch (e) {} call.pc = null; }
  if (call.localStream) { call.localStream.getTracks().forEach(t => t.stop()); call.localStream = null; }
  $("localVideo").srcObject = null;
  $("remoteVideo").srcObject = null;
  $("remoteVideo").style.display = "none";
  stopRinging();
  call.callId = null; call.peer = null; call.seconds = 0;
}

async function startCall(type) {
  if (!state.currentChat || state.currentChat.type !== "usertouser") return;
  if (!can("voice_video_calls")) { toast("Permission denied: voice_video_calls", "error"); return; }
  const peer = state.currentChat.other_user;
  if (!state.online.has(peer)) { toast(peer + " is offline", "error"); return; }
  if (call.pc) { toast("A call is already active", "error"); return; }

  try {
    call.localStream = await getUserMediaForCall(type);
  } catch (e) {
    toast("Microphone/camera access denied", "error");
    return;
  }
  showCallOverlay(peer, type, true);
  startRinging();

  const callId = Math.random().toString(36).slice(2) + Date.now().toString(36);
  call.callId = callId;

  const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
  call.pc = pc;
  call.localStream.getTracks().forEach(t => pc.addTrack(t, call.localStream));
  pc.onicecandidate = e => {
    if (e.candidate && state.socket) {
      state.socket.emit("ice_candidate", { call_id: callId, to: peer, candidate: e.candidate });
    }
  };
  pc.ontrack = e => {
    const rv = $("remoteVideo");
    rv.srcObject = e.streams[0];
    rv.style.display = "block";
    setCallState("Connected");
    startCallTimer();
  };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === "connected") { setCallState("Connected"); startCallTimer(); }
    if (pc.connectionState === "failed" || pc.connectionState === "disconnected") {
      toast("Call connection lost", "error");
      endCall();
    }
  };

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  state.socket.emit("call_user", { call_id: callId, to: peer, type, sdp: pc.localDescription });
}

async function onIncomingCall(d) {
  if (call.pc) {
    if (state.socket) state.socket.emit("reject_call", { call_id: d.call_id, to: d.from });
    return;
  }
  call.callId = d.call_id;
  call.peer = d.from;
  call.type = d.type || "voice";
  call.isCaller = false;

  $("incomingAvatar").innerHTML = `<div style="width:112px;height:112px;border-radius:50%;background:${avatarColor(d.from)};display:flex;align-items:center;justify-content:center;font-size:44px;color:#fff">${escapeHtml(initials(d.from))}</div>`;
  $("incomingName").textContent = d.from;
  $("incomingType").textContent = "Incoming " + (d.type === "video" ? "video" : "voice") + " call…";
  $("incomingCall").classList.remove("hidden");
  $("callOverlay").classList.add("hidden");
  startRinging();
  showSystemNotification("Incoming call from " + d.from, d.type === "video" ? "Video call" : "Voice call");

  // store caller's offer for acceptance
  call.pendingOffer = d.sdp || null;
}

async function acceptIncoming() {
  if (!call.peer) return;
  stopRinging();
  $("incomingCall").classList.add("hidden");
  showCallOverlay(call.peer, call.type, false);
  try {
    call.localStream = await getUserMediaForCall(call.type);
  } catch (e) {
    toast("Microphone/camera access denied", "error");
    endCall();
    return;
  }
  $("localVideo").srcObject = call.localStream;
  $("localVideo").style.display = call.type === "video" ? "block" : "none";

  const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
  call.pc = pc;
  call.localStream.getTracks().forEach(t => pc.addTrack(t, call.localStream));
  pc.onicecandidate = e => {
    if (e.candidate && state.socket) {
      state.socket.emit("ice_candidate", { call_id: call.callId, to: call.peer, candidate: e.candidate });
    }
  };
  pc.ontrack = e => {
    const rv = $("remoteVideo");
    rv.srcObject = e.streams[0];
    rv.style.display = "block";
    setCallState("Connected");
    startCallTimer();
  };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === "connected") { setCallState("Connected"); startCallTimer(); }
    if (pc.connectionState === "failed") { toast("Call connection lost", "error"); endCall(); }
  };

  if (call.pendingOffer) {
    await pc.setRemoteDescription(call.pendingOffer);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    state.socket.emit("accept_call", { call_id: call.callId, to: call.peer, sdp: pc.localDescription });
  }
}

async function onCallAccepted(d) {
  if (!call.pc || !call.isCaller) return;
  stopRinging();
  setCallState("Connecting…");
  if (d.sdp) {
    try { await call.pc.setRemoteDescription(d.sdp); } catch (e) { toast("Call failed: " + e.message, "error"); endCall(); }
  }
}

function onCallRejected(d) {
  if (call.callId !== d.call_id) return;
  stopRinging();
  toast(call.peer + " declined the call", "info");
  hideCallOverlay();
}

async function onIceCandidate(d) {
  if (!call.pc || call.callId !== d.call_id) return;
  try {
    await call.pc.addIceCandidate(d.candidate);
  } catch (e) { /* candidate race — ignore */ }
}

function onCallEnded(d) {
  if (call.callId && d.call_id && call.callId !== d.call_id) return;
  stopRinging();
  toast("Call ended", "info");
  hideCallOverlay();
}

function endCall() {
  if (state.socket && call.callId && call.peer) {
    state.socket.emit("end_call", { call_id: call.callId, to: call.peer });
  }
  hideCallOverlay();
}

function startCallTimer() {
  if (call.timer) return;
  call.seconds = 0;
  call.timer = setInterval(() => {
    call.seconds++;
    const m = String(Math.floor(call.seconds / 60)).padStart(2, "0");
    const s = String(call.seconds % 60).padStart(2, "0");
    $("callTimer").textContent = m + ":" + s;
    $("callTimer").classList.remove("hidden");
  }, 1000);
}

/* ---------------- chat info ---------------- */
let infoChat = null;

async function loadChatInfo() {
  if (!state.currentChat) return;
  const d = await api("GET", "/api/chats/" + state.currentChat.uuid);
  infoChat = d;
  $("infoChatName").textContent = d.name || "Chat info";
  $("infoStats").innerHTML = `
    <div class="info-stat"><b>${d.members.length}</b><span>members</span></div>
    <div class="info-stat"><b>${d.admins.length}</b><span>admins</span></div>
    <div class="info-stat"><b>${d.type === "usertouser" ? "direct" : d.type}</b><span>type</span></div>`;

  $("infoMembers").innerHTML = d.members.map(m => `
    <div class="info-member">
      ${avatarEl(m.username, m.profile.avatar)}
      <div class="info-member-name">${escapeHtml(m.profile.display_name || m.username)}</div>
      ${d.admins.includes(m.username) ? '<span class="info-member-role admin-tag">admin</span>' : ""}
      <span class="info-member-role">${escapeHtml(m.role)}</span>
      ${m.username !== state.me && (d.admins.includes(state.me)) ? `<button class="icon-btn kick-btn" data-user="${escapeHtml(m.username)}" title="Remove"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>` : ""}
    </div>`).join("");

  $("infoActions").innerHTML = `
    ${d.type !== "usertouser" && (d.admins.includes(state.me)) && can("edit_chats")
      ? `<div class="add-member-row" style="display:flex;gap:8px">
          <input type="text" id="addMemberInput" placeholder="username to add" style="flex:1;padding:9px 13px;border-radius:10px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:13.5px;outline:none">
          <button class="btn btn-secondary btn-sm" id="addMemberBtn">Add</button>
        </div>` : ""}
    <button class="btn btn-secondary btn-sm" id="leaveChatBtn">${d.type === "usertouser" ? "Delete chat" : "Leave chat"}</button>
    ${d.type !== "usertouser" && d.admins.includes(state.me)
      ? `<button class="btn btn-danger btn-sm" id="deleteChatBtn">Delete chat for everyone</button>` : ""}`;

  const am = $("addMemberBtn");
  if (am) am.addEventListener("click", async () => {
    const name = $("addMemberInput").value.trim();
    if (!name) return;
    try { await api("POST", `/api/chats/${d.uuid}/members`, { username: name }); toast(name + " added", "success"); loadChatInfo(); loadChats(); }
    catch (e) { toast(e.message, "error"); }
  });
  const muteBtn = $("muteChatBtn");
  if (muteBtn) muteBtn.addEventListener("click", async () => {
    try {
      await api("POST", `/api/chats/${d.uuid}/mute`, { muted: true });
      toast("Muted. Tap again in settings if you want sound back.", "success");
    } catch (e) { toast(e.message, "error"); }
  });
  $("leaveChatBtn").addEventListener("click", async () => {
    try {
      if (d.type === "usertouser") await api("DELETE", `/api/chats/${d.uuid}/delete`);
      else await api("POST", `/api/chats/${d.uuid}/leave`);
      toast("Done", "success");
      closeInfoDrawer();
      setCurrentChat(null);
      loadChats();
    } catch (e) { toast(e.message, "error"); }
  });
  $("infoMembers").querySelectorAll(".kick-btn").forEach(b => {
    b.addEventListener("click", async () => {
      try { await api("DELETE", `/api/chats/${d.uuid}/members/${b.dataset.user}`); toast(b.dataset.user + " removed", "success"); loadChatInfo(); loadChats(); }
      catch (e) { toast(e.message, "error"); }
    });
  });
  fillInfoMedia();
}

/* ---------------- create chat modal ---------------- */
let pickerUsers = [];

async function openCreateChat() {
  if (!can("create_chats")) { toast("Permission denied: create_chats", "error"); return; }
  const d = await api("GET", "/api/users");
  pickerUsers = d.filter(u => u.username !== state.me);
  renderPicker("");
  $("newChatName").value = "";
  $("memberSearch").value = "";
  // only group / channel can be created from the modal — direct chats are
  // started by clicking a user in the search results
  $("newChatName").closest(".field").style.display = "block";
  openModal("createChatModal");
}

function renderPicker(q) {
  const list = $("memberPicker");
  const users = pickerUsers.filter(u => !q || u.username.toLowerCase().includes(q) || (u.display_name || "").toLowerCase().includes(q));
  if (!users.length) {
    list.innerHTML = `<div style="padding:14px;font-size:13px;color:var(--text-secondary)">No users found. Try an exact username.</div>`;
    return;
  }
  list.innerHTML = users.map(u => `
    <label class="member-item">
      ${avatarEl(u.username, u.avatar)}
      <span class="member-item-name">${escapeHtml(u.display_name || u.username)}</span>
      <span style="font-size:11.5px;color:var(--text-secondary)">@${escapeHtml(u.username)}</span>
      <input type="checkbox" value="${escapeHtml(u.username)}">
    </label>`).join("");
  updatePickerCount();
  list.querySelectorAll("input").forEach(i => i.addEventListener("change", updatePickerCount));
}

function updatePickerCount() {
  const n = $("memberPicker").querySelectorAll("input:checked").length;
  $("pickerCount").textContent = n + " selected";
}

async function createChat() {
  const type = document.querySelector("#chatTypeSeg .active").dataset.type; // group | channel
  const name = $("newChatName").value.trim();
  const users = [...$("memberPicker").querySelectorAll("input:checked")].map(i => i.value);
  if (!users.length) { toast("Pick at least one member", "error"); return; }
  if (!name) { toast("Chat name is required", "error"); return; }
  try {
    const chat = await api("POST", "/api/createchat", { name, type, users });
    closeModal("createChatModal");
    await loadChats();
    await openChat(chat.uuid);
  } catch (e) { toast(e.message, "error"); }
}

/* ---------------- mobile drawer ---------------- */
function isMobileUi() {
  return document.documentElement.classList.contains("efadro-mobile")
    || window.matchMedia("(max-width: 760px)").matches;
}

function openDrawer() {
  const side = $("settingsDrawer") || $("sidebar");
  const ov = $("drawerOverlay");
  if (!side || !ov) return;
  side.classList.add("open");
  ov.classList.remove("hidden");
}

function closeDrawer() {
  const side = $("settingsDrawer");
  const ov = $("drawerOverlay");
  if (side) side.classList.remove("open");
  if ($("sidebar")) $("sidebar").classList.remove("open");
  if (ov) ov.classList.add("hidden");
}

function toggleDrawer() {
  const side = $("settingsDrawer");
  if (side && side.classList.contains("open")) closeDrawer();
  else openDrawer();
}

function fitVisualViewport() {
  const vv = window.visualViewport;
  const h = vv ? Math.round(vv.height) : window.innerHeight;
  document.documentElement.style.setProperty("--vv-height", h + "px");
}

window.efadroBack = function () {
  if ($("lightbox") && !$("lightbox").classList.contains("hidden")) {
    $("lightbox").classList.add("hidden");
    return true;
  }
  const openModalEl = document.querySelector(".modal-overlay:not(.hidden)");
  if (openModalEl) {
    openModalEl.classList.add("hidden");
    return true;
  }
  if ($("sidebar") && $("sidebar").classList.contains("open")) {
    closeDrawer();
    return true;
  }
  if (state.currentChat && isMobileUi()) {
    setCurrentChat(null);
    return true;
  }
  return false;
};

/* ---------------- settings ---------------- */
function showSettingsPane(tab) {
  if (!tab) return;
  document.querySelectorAll(".settings-tabs button").forEach(x => {
    x.classList.toggle("active", x.dataset.tab === tab);
  });
  document.querySelectorAll(".settings-pane").forEach(p => p.classList.remove("active"));
  const pane = $("pane-" + tab);
  if (pane) pane.classList.add("active");
}

function openSettings(tab) {
  $("displayNameInput").value = state.myDisplayName || state.me;
  $("bioInput").value = "";
  const avatar = localStorage.getItem("myAvatar") || "";
  $("settingsAvatar").innerHTML = avatar && !avatar.startsWith("#")
    ? `<img src="${escapeHtml(avatar)}" alt="">`
    : initials(state.me);

  api("GET", "/api/profile").then(p => {
    $("displayNameInput").value = p.display_name || state.me;
    $("bioInput").value = p.bio || "";
    if (p.avatar && !p.avatar.startsWith("#")) {
      $("settingsAvatar").innerHTML = `<img src="${escapeHtml(p.avatar)}" alt="">`;
    }
  }).catch(() => {});
  api("GET", "/api/me").then(fillAccountExtras).catch(() => {});

  // theme seg
  document.querySelectorAll("#themeSeg button").forEach(b => {
    b.classList.toggle("active", b.dataset.theme === (document.documentElement.classList.contains("dark") ? "dark" : "light"));
  });
  // radius seg
  const cur = localStorage.getItem("efadro-msg-radius") || "18";
  document.querySelectorAll("#radiusSeg button").forEach(b => {
    b.classList.toggle("active", b.dataset.r === cur);
  });
  // swatches
  const sw = $("settingsSwatches");
  const curAccent = localStorage.getItem("efadro-accent") || "#0A84FF";
  sw.innerHTML = ACCENT_COLORS.map(c =>
    `<button class="swatch ${c === curAccent ? "active" : ""}" style="background:${c}" data-color="${c}" title="${c}"></button>`
  ).join("");
  loadDeveloperApps();
  syncPremiumGates();
  openModal("settingsModal");
  if (tab) showSettingsPane(tab);
}

/* ---------------- developer (API login) ---------------- */
function copyText(text, label) {
  const done = () => toast((label || "Copied") + " — " + text.slice(0, 24) + "…", "ok");
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, done) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); done(); } catch (e) { toast("Copy failed", "error"); }
  ta.remove();
}

function oauthPageUrl(redirectUri) {
  const page = new URL("../oauth/", location.href).href;
  const u = new URL(page);
  u.searchParams.set("client_id", "CLIENT_ID");
  u.searchParams.set("redirect_uri", redirectUri || "https://your-app.example.com/cb");
  u.searchParams.set("state", "optional-state");
  return u.href;
}

async function loadDeveloperApps() {
  const box = $("devAppsList");
  try {
    const apps = await api("GET", "/api/developer/apps");
    const page = new URL("../oauth/", location.href).href;
    $("devAuthorizeUrl").textContent = page + "?client_id=…&redirect_uri=…&state=…";
    if (!apps.length) {
      box.innerHTML = `<p class="dev-empty">No apps yet. Create one to get a client ID and API key.</p>`;
      return;
    }
    box.innerHTML = apps.map(a => {
      const u = new URL(page);
      u.searchParams.set("client_id", a.client_id);
      u.searchParams.set("redirect_uri", a.redirect_uri);
      return `<div class="dev-row">
        <div class="dev-row-main">
          <b>${escapeHtml(a.name)}</b>
          <small>client_id: <code>${escapeHtml(a.client_id)}</code></small>
          <small>redirect: <code>${escapeHtml(a.redirect_uri)}</code></small>
          <a href="${escapeHtml(u.href)}" target="_blank" rel="noopener">API login page ↗</a>
        </div>
        <div class="dev-row-actions">
          <button class="btn btn-secondary btn-sm" data-dev="copy-cid" data-cid="${escapeHtml(a.client_id)}">Copy ID</button>
          <button class="btn btn-secondary btn-sm" data-dev="key" data-cid="${escapeHtml(a.client_id)}">New API key</button>
          <button class="btn btn-danger btn-sm" data-dev="del" data-cid="${escapeHtml(a.client_id)}">Delete</button>
        </div>
      </div>`;
    }).join("");
  } catch (e) {
    if (e.status === 403 || (e.data &rror === "premium_required")) {
      box.innerHTML = `<p class="dev-empty">Developer apps need Premium.</p>`;
      return;
    }
    box.innerHTML = `<p class="dev-empty">Could not load apps.</p>`;
  }
}

async function createDevApp() {
  const name = $("devAppName").value.trim();
  const redirect = $("devRedirectUri").value.trim();
  try {
    const app = await api("POST", "/api/developer/apps", { name, redirect_uri: redirect });
    $("devAppName").value = "";
    $("devRedirectUri").value = "";
    const box = $("devSecretBox");
    box.classList.remove("hidden");
    box.innerHTML = `
      <div class="dev-secret-title">App created — save these now</div>
      <div class="dev-secret-row"><span>Client ID</span><code>${escapeHtml(app.client_id)}</code><button class="btn btn-secondary btn-sm" data-secret="copy" data-val="${escapeHtml(app.client_id)}">Copy</button></div>
      <div class="dev-secret-row"><span>API key</span><code>${escapeHtml(app.api_key)}</code><button class=   <div class="dev-secret-row"><span>Client ID</span><code>${escapeHtml(app.client_id)}</code><button class="btn btn-secondary btn-sm" data-secret="copy" data-val="${escapeHtml(app.client_id)}">Copy</button></div>
      <div class="dev-secret-row"><span>API key</span><code>${escapeHtml(app.api_key)}</code><button class="btn btn-secondary btn-sm" data-secret="copy" data-val="${escapeHtml(app.api_key)}">Copy</button></div>
      <p class="dev-secret-note">The API key is shown only once. Treat it like a password.</p>`;
    toast("App created", "ok");
    loadDeveloperApps();
  } catch (e) { toast(e.message, "error"); }
}

async function regenerateDevKey(cid) {
  if (!confirm("Rotate this app's API key? The old key stops working immediately.")) return;
  try {
    const r = await api("POST", `/api/developer/apps/${cid}/key`, {});
    const box = $("devSecretBox");
    box.classList.remove("hidden");
    box.innerHTML = `
      <div class="dev-secret-title">New API key</div>
      <div class="dev-secret-row"><span>API key</span><code>${escapeHtml(r.api_key)}</code><button class="btn btn-secondary btn-sm" data-secret="copy" data-val="${escapeHtml(r.api_key)}">Copy</button></div>
      <p class="dev-secret-note">Shown only once. The previous key no longer works.</p>`;
    toast("API key rotated", "ok");
    loadDeveloperApps();
  } catch (e) { toast(e.message, "error"); }
}

async function deleteDevApp(cid) {
  if (!confirm("Delete this app? Users will no longer be able to sign in with it.")) return;
  try {
    await api("DELETE", `/api/developer/apps/${cid}`);
    toast("App deleted", "ok");
    loadDeveloperApps();
  } catch (e) { toast(e.message, "error"); }
}

/* ---------------- control panel ---------------- */
async function openCp() {
  if (!can("view_cp")) { toast("Permission denied: view_cp", "error"); return; }
  openModal("cpModal");
  loadCpStats();
  loadCpUsers();
  loadCpChats();
  loadCpRoles();
  loadCpBlacklist();
}

async function loadCpStats() {
  try {
    const s = await api("GET", "/api/cp/stats");
    $("statGrid").innerHTML = `
      <div class="stat-card"><b>${s.users}</b><span>users</span></div>
      <div class="stat-card"><b>${s.chats}</b><span>chats</span></div>
      <div class="stat-card"><b>${s.messages}</b><span>messages</span></div>
      <div class="stat-card"><b>${s.files}</b><span>files</span></div>
      <div class="stat-card"><b>${s.premium_users}</b><span>premium</span></div>
      <div class="stat-card"><b>${s.online}</b><span>online</span></div>
      <div class="stat-card"><b>${s.blacklist}</b><span>blacklisted IPs</span></div>
      <div class="stat-card"><b>${state.chats.length}</b><span>my chats</span></div>`;
    renderOnlineChips();
  } catch (e) { /* noop */ }
}

function renderOnlineChips() {
  const chips = [...state.online].map(u => `<span class="online-chip"><i></i>${escapeHtml(u)}</span>`).join("") || "<span style='font-size:13px;color:var(--text-secondary)'>Nobody online</span>";
  $("onlineChips").innerHTML = chips;
}

async function loadCpUsers() {
  try {
    const users = await api("GET", "/api/cp/users");
    $("cpUsersTable").innerHTML = `<thead><tr><th>User</th><th>Role</th><th>Premium</th><th>E2EE key</th><th>Actions</th></tr></thead><tbody>` +
      users.map(u => `<tr data-user="${escapeHtml(u.username)}">
        <td><div class="cp-user-cell">${avatarEl(u.username, u.avatar)}<div><b>${escapeHtml(u.display_name || u.username)}</b><br><span style="color:var(--text-secondary);font-size:11.5px">@${escapeHtml(u.username)}</span></div></div></td>
        <td><select class="role-select" data-user="${escapeHtml(u.username)}">${cpRoleOptions(u.role)}</select></td>
        <td>${u.premium.active ? `<span style="color:#FF9F0A;font-weight:700">★ ${u.premium.days_left}d</span>` : "—"}</td>
        <td>${u.public_key ? '<span style="color:#30D158">✓</span>' : '<span style="color:var(--text-secondary)">—</span>'}</td>
        <td><div class="cp-actions">
          <button class="icon-btn" data-act="password" data-user="${escapeHtml(u.username)}" title="Set password"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
          <button class="icon-btn" data-act="ban" data-user="${escapeHtml(u.username)}" title="Ban"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M4.9 4.9l14.2 14.2"/></svg></button>
          <button class="icon-btn danger" data-act="delete" data-user="${escapeHtml(u.username)}" title="Delete user"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
        </div></td>
      </tr>`).join("") + "</tbody>";

    // role change
    $("cpUsersTable").querySelectorAll(".role-select").forEach(sel => {
      sel.addEventListener("change", async () => {
        try { await api("POST", "/api/cp/users/role", { username: sel.dataset.user, role: sel.value }); toast(sel.dataset.user + " → " + sel.value, "success"); }
        catch (e) { toast(e.message, "error"); loadCpUsers(); }
      });
    });
    // actions
    $("cpUsersTable").querySelectorAll("[data-act]").forEach(btn => {
      btn.addEventListener("click", async () => {
        const u = btn.dataset.user, act = btn.dataset.act;
        if (act === "password") {
          const pw = prompt("New password for " + u + ":");
          if (!pw) return;
          try { await api("POST", "/api/cp/users/password", { username: u, new_password: pw }); toast("Password updated", "success"); }
          catch (e) { toast(e.message, "error"); }
        } else if (act === "ban") {
          if (!confirm("Ban " + u + "?")) return;
          try { await api("POST", "/api/cp/users/ban", { username: u }); toast(u + " banned", "success"); loadCpUsers(); }
          catch (e) { toast(e.message, "error"); }
        } else if (act === "delete") {
          if (!confirm("Permanently delete " + u + "?")) return;
          try { await api("POST", "/api/cp/users/delete", { username: u }); toast(u + " deleted", "success"); loadCpUsers(); loadCpStats(); }
          catch (e) { toast(e.message, "error"); }
        }
      });
    });
  } catch (e) { toast(e.message, "error"); }
}

function cpRoleOptions(current) {
  const roles = ["owner", "admin", "moderator", "user", "bot", "banned"];
  return roles.map(r => `<option value="${r}" ${r === current ? "selected" : ""}>${r}</option>`).join("");
}

async function loadCpChats() {
  try {
    const chats = await api("GET", "/api/cp/chats");
    $("cpChatsTable").innerHTML = `<thead><tr><th>Name</th><th>Type</th><th>Members</th><th>Messages</th><th></th></tr></thead><tbody>` +
      chats.map(c => `<tr>
        <td><b>${escapeHtml(c.name)}</b><br><span style="color:var(--text-secondary);font-size:11.5px">${c.uuid.slice(0, 8)}…</span></td>
        <td>${escapeHtml(c.type)}</td>
        <td>${c.users.length} · ${escapeHtml(c.users.slice(0, 3).join(", "))}${c.users.length > 3 ? "…" : ""}</td>
        <td>${c.messages}</td>
        <td><button class="icon-btn danger" data-uuid="${escapeHtml(c.uuid)}" title="Delete chat"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button></td>
      </tr>`).join("") + "</tbody>";
    $("cpChatsTable").querySelectorAll("[data-uuid]").forEach(btn => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete this chat and all its messages?")) return;
        try { await api("POST", "/api/cp/chats/delete", { uuid: btn.dataset.uuid }); toast("Chat deleted", "success"); loadCpChats(); }
        catch (e) { toast(e.message, "error"); }
      });
    });
  } catch (e) { toast(e.message, "error"); }
}

let cpRoles = {};

async function loadCpRoles() {
  try {
    const d = await api("GET", "/api/cp/roles");
    cpRoles = d.roles;
    renderRolesMatrix();
    $("rolesRaw").value = Object.entries(cpRoles).map(([r, p]) => r + ":" + p.join(",")).join("\n");
  } catch (e) { toast(e.message, "error"); }
}

function renderRolesMatrix() {
  const box = $("rolesMatrix");
  box.innerHTML = Object.entries(cpRoles).map(([role, perms]) => `
    <div class="roles-row">
      <b>${escapeHtml(role)}</b>
      ${PERMISSION_LABELS.map(([perm, label]) => `
        <label><input type="checkbox" data-role="${escapeHtml(role)}" data-perm="${perm}" ${perms.includes(perm) ? "checked" : ""}>${label}</label>
      `).join("")}
    </div>`).join("");
  box.querySelectorAll("input").forEach(i => {
    i.addEventListener("change", () => {
      const role = i.dataset.role;
      const perm = i.dataset.perm;
      cpRoles[role] = cpRoles[role] || [];
      if (i.checked && !cpRoles[role].includes(perm)) cpRoles[role].push(perm);
      if (!i.checked) cpRoles[role] = cpRoles[role].filter(p => p !== perm);
      $("rolesRaw").value = Object.entries(cpRoles).map(([r, p]) => r + ":" + p.join(",")).join("\n");
    });
  });
}

async function loadCpBlacklist() {
  try {
    const d = await api("GET", "/api/cp/blacklist");
    $("blacklistTable").innerHTML = `<thead><tr><th>IP address</th><th></th></tr></thead><tbody>` +
      (d.blacklist.length ? d.blacklist.map(ip => `<tr><td><code>${escapeHtml(ip)}</code></td><td><button class="icon-btn danger" data-ip="${escapeHtml(ip)}"><svg class="svg-icon-small" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button></td></tr>`).join("")
        : `<tr><td colspan="2" style="color:var(--text-secondary);text-align:center">Empty</td></tr>`) + "</tbody>";
    $("blacklistTable").querySelectorAll("[data-ip]").forEach(btn => {
      btn.addEventListener("click", async () => {
        try { await api("DELETE", "/api/cp/blacklist?ip=" + encodeURIComponent(btn.dataset.ip)); loadCpBlacklist(); }
        catch (e) { toast(e.message, "error"); }
      });
    });
  } catch (e) { toast(e.message, "error"); }
}

/* ---------------- premium look ---------------- */
const WALLPAPERS = [
  { id: "none", label: "None", css: "" },
  { id: "dusk", label: "Dusk", css: "linear-gradient(180deg,#2b1a4e,#0b1026)" },
  { id: "ocean", label: "Ocean", css: "linear-gradient(165deg,#0a3d62,#082c44)" },
  { id: "forest", label: "Forest", css: "linear-gradient(180deg,#14332a,#0b1f18)" },
  { id: "sunset", label: "Sunset", css: "linear-gradient(180deg,#4a1942,#c44536)" },
  { id: "midnight", label: "Night", css: "linear-gradient(180deg,#1c1c1e,#000)" },
];

function applyPremiumLook() {
  const d = document.documentElement;
  if (!isPremium()) {
    d.style.removeProperty("--msg-font");
    d.style.removeProperty("--chat-wallpaper");
    d.style.removeProperty("--msg-bubble");
    d.style.setProperty("--msg-mine", "var(--accent)");
    d.classList.remove("compact-chats");
    return;
  }
  const mine = localStorage.getItem("efadro-bubble-mine");
  const theirs = localStorage.getItem("efadro-bubble-theirs");
  const font = localStorage.getItem("efadro-msg-font");
  const wp = localStorage.getItem("efadro-wallpaper");
  const compact = localStorage.getItem("efadro-compact") === "1";
  if (mine) d.style.setProperty("--msg-mine", mine);
  else d.style.setProperty("--msg-mine", "var(--accent)");
  if (theirs) d.style.setProperty("--msg-bubble", theirs);
  else d.style.removeProperty("--msg-bubble");
  if (font) d.style.setProperty("--msg-font", font + "px");
  else d.style.removeProperty("--msg-font");
  if (wp) d.style.setProperty("--chat-wallpaper", wp);
  else d.style.removeProperty("--chat-wallpaper");
  d.classList.toggle("compact-chats", compact);
}

function syncPremiumGates() {
  const extras = $("appearanceExtras");
  const lock = $("extrasLock");
  if (extras) extras.classList.toggle("locked", !isPremium());
  if (lock) lock.classList.toggle("hidden", isPremium());
  const devLock = $("devPremiumLock");
  const devBody = $("devPremiumBody");
  if (devLock) devLock.classList.toggle("hidden", isPremium());
  if (devBody) devBody.classList.toggle("hidden", !isPremium());
  syncPremiumLookFields();
}

function syncPremiumLookFields() {
  const mine = $("bubbleMine");
  if (mine) mine.value = localStorage.getItem("efadro-bubble-mine") || localStorage.getItem("efadro-accent") || "#0A84FF";
  const theirs = $("bubbleTheirs");
  if (theirs) theirs.value = localStorage.getItem("efadro-bubble-theirs") || "#e9e9ed";
  const font = localStorage.getItem("efadro-msg-font") || "14.5";
  document.querySelectorAll("#fontSeg button").forEach(b => b.classList.toggle("active", b.dataset.fs === font));
  const compact = $("compactChats");
  if (compact) compact.checked = localStorage.getItem("efadro-compact") === "1";
  const box = $("wallpaperPresets");
  if (!box) return;
  const cur = localStorage.getItem("efadro-wallpaper-id") || "none";
  box.innerHTML = WALLPAPERS.map(w =>
    `<button type="button" class="wp-swatch ${w.id === cur ? "active" : ""}" data-wp="${w.id}" title="${w.label}" style="background:${w.css || "var(--bg)"}"></button>`
  ).join("");
}

/* ---------------- stories ---------------- */
function storyKindAccept(kind) {
  if (kind === "video") return "video/*";
  if (kind === "music") return "audio/*";
  return "image/*";
}

async function loadStories() {
  try {
    const d = await api("GET", "/api/stories");
    state.stories = d.stories || [];
    state.storyPostedToday = d.posted_today || 0;
    if (d.limits) state.limits = d.limits;
    if (d.daily_limit) state.limits.stories_per_day = d.daily_limit;
    renderStories();
  } catch (e) { /* ignore */ }
}

function renderStories() {
  const rail = $("storiesRail");
  const collapsed = $("storiesCollapsed");
  const bar = $("storiesBar");
  if (!rail || !collapsed) return;
  const groups = state.stories || [];
  const n = groups.reduce((s, g) => s + (g.items || []).length, 0);
  collapsed.textContent = n ? (n === 1 ? "1 story" : n + " stories") : "Stories";
  rail.innerHTML = groups.map(g => {
    const name = g.username === state.me ? "You" : (g.display_name || g.username);
    return `<button type="button" class="story-ring" data-story-user="${escapeHtml(g.username)}" title="${escapeHtml(name)}">
      ${avatarEl(g.username, g.avatar)}
      <div class="story-name">${escapeHtml(name)}</div>
    </button>`;
  }).join("");
  if (bar && !bar.dataset.wired) {
    bar.dataset.wired = "1";
    const yoursBtn = $("yourStoryBtn");
    if (yoursBtn) yoursBtn.addEventListener("click", openStoryCompose);
    rail.addEventListener("click", e => {
      const ring = e.target.closest("[data-story-user]");
      if (ring) openStoryViewer(ring.dataset.storyUser);
    });
    collapsed.addEventListener("click", () => {
      const sc = $("sidebarChats");
      if (sc) sc.scrollTo({ top: 0, behavior: "smooth" });
    });
  }
  updateStoriesCollapse();
}

function updateStoriesCollapse() {
  const sc = $("sidebarChats");
  const bar = $("storiesBar");
  if (!sc || !bar) return;
  bar.classList.toggle("at-top", sc.scrollTop < 12);
}

function openStoryCompose() {
  const lim = (state.limits && state.limits.stories_per_day) || (isPremium() ? 40 : 4);
  const used = state.storyPostedToday || 0;
  $("storyQuota").textContent = `You can post ${lim} stor${lim === 1 ? "y" : "ies"} a day. Used ${used}/${lim} today.`
    + (isPremium() ? "" : " Premium raises this to 40.");
  $("storyCaptionInput").value = "";
  $("storyFileInput").value = "";
  const kind = document.querySelector("#storyKindSeg .active");
  $("storyFileInput").accept = storyKindAccept(kind ? kind.dataset.kind : "image");
  openModal("storyComposeModal");
}

async function postStory() {
  const kindBtn = document.querySelector("#storyKindSeg .active");
  const kind = kindBtn ? kindBtn.dataset.kind : "image";
  const file = $("storyFileInput").files[0];
  if (!file) { toast("Pick an image, video or track", "info"); return; }
  let mime = (file.type || "").toLowerCase();
  if (!mime) {
    const n = (file.name || "").toLowerCase();
    if (kind === "video") mime = n.endsWith(".webm") ? "video/webm" : "video/mp4";
    else if (kind === "music") mime = n.endsWith(".ogg") ? "audio/ogg" : "audio/mpeg";
    else mime = n.endsWith(".png") ? "image/png" : n.endsWith(".webp") ? "image/webp" : n.endsWith(".gif") ? "image/gif" : "image/jpeg";
  }
  if (mime === "image/jpg") mime = "image/jpeg";
  if (mime === "audio/mp3") mime = "audio/mpeg";
  const cap = maxFileBytes();
  if (file.size > cap) {
    toast("That file is over the " + Math.round(cap / (1024 * 1024 * 1024)) + " GB limit.", "error");
    return;
  }
  const uploading = toastEl("Uploading story…");
  try {
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch(SERVER + "/api/upload", {
      method: "POST",
      headers: { "X-Username": state.me },
      credentials: "include",
      body: fd,
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "upload failed");
    const rec = await api("POST", "/api/stories", {
      kind,
      file_id: d.file_id,
      mime,
      text: ($("storyCaptionInput").value || "").trim(),
    });
    uploading.remove();
    closeModal("storyComposeModal");
    state.storyPostedToday = rec.posted_today || state.storyPostedToday + 1;
    toast("Story posted", "success");
    await loadStories();
  } catch (e) {
    uploading.remove();
    toast(e.message || "Could not post story", "error");
  }
}

let storyView = { groups: [], gi: 0, ii: 0, timer: null };

function openStoryViewer(username) {
  const groups = state.stories || [];
  let gi = groups.findIndex(g => g.username === username);
  if (gi < 0) gi = 0;
  if (!groups.length) return;
  storyView = { groups, gi, ii: 0, timer: null };
  $("storyViewer").classList.remove("hidden");
  showStoryItem();
}

function closeStoryViewer() {
  if (storyView.timer) { clearTimeout(storyView.timer); storyView.timer = null; }
  const stage = $("storyStage");
  if (stage) stage.innerHTML = "";
  $("storyViewer").classList.add("hidden");
}

function showStoryItem() {
  if (storyView.timer) { clearTimeout(storyView.timer); storyView.timer = null; }
  const g = storyView.groups[storyView.gi];
  if (!g) { closeStoryViewer(); return; }
  const items = g.items || [];
  if (storyView.ii >= items.length) {
    storyView.gi += 1; storyView.ii = 0;
    if (storyView.gi >= storyView.groups.length) { closeStoryViewer(); return; }
    return showStoryItem();
  }
  if (storyView.ii < 0) {
    storyView.gi -= 1;
    if (storyView.gi < 0) { storyView.gi = 0; storyView.ii = 0; }
    else storyView.ii = (storyView.groups[storyView.gi].items || []).length - 1;
    return showStoryItem();
  }
  const item = items[storyView.ii];
  $("storyAuthor").textContent = (g.display_name || g.username) + (g.username === state.me ? " (you)" : "");
  $("storyCaptionView").textContent = item.text || "";
  const prog = $("storyProgress");
  prog.innerHTML = items.map((_, i) => `<i class="${i < storyView.ii ? "done" : ""}">${i === storyView.ii ? "<b></b>" : ""}</i>`).join("");
  const url = fileUrl(item.file_id, item.mime, "story", false);
  const stage = $("storyStage");
  if (item.kind === "video") {
    stage.innerHTML = `<video src="${escapeHtml(url)}" autoplay playsinline controls></video>`;
    const v = stage.querySelector("video");
    v.addEventListener("ended", () => { storyView.ii += 1; showStoryItem(); });
  } else if (item.kind === "music") {
    stage.innerHTML = `<div class="story-music"><audio src="${escapeHtml(url)}" autoplay controls></audio></div>`;
    const a = stage.querySelector("audio");
    a.addEventListener("ended", () => { storyView.ii += 1; showStoryItem(); });
  } else {
    stage.innerHTML = `<img src="${escapeHtml(url)}" alt="">`;
    const bar = prog.querySelector("i:not(.done) b");
    if (bar) {
      bar.style.transition = "width 5s linear";
      requestAnimationFrame(() => { bar.style.width = "100%"; });
    }
    storyView.timer = setTimeout(() => { storyView.ii += 1; showStoryItem(); }, 5000);
  }
}

/* ---------------- premium ---------------- */
let premiumState = null;

function formatPremiumLeft(st) {
  if (!st || !st.active) return "";
  const s = st.seconds_left || (st.days_left * 86400) || 0;
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  if (d >= 1) return d + " day" + (d === 1 ? "" : "s") + " left";
  if (h >= 1) return h + " hour" + (h === 1 ? "" : "s") + " left";
  return "less than an hour left";
}

function formatPremiumExpiry(st) {
  if (!st || !st.expiry) return "";
  try {
    return new Date(st.expiry * 1000).toLocaleDateString(undefined, {
      year: "numeric", month: "short", day: "numeric"
    });
  } catch (e) { return ""; }
}

async function openPremium() {
  openModal("premiumModal");
  await loadPremiumState();
}

async function loadPremiumState() {
  try {
    const d = await api("GET", "/api/premium");
    premiumState = d;
    const st = d.status || {};
    state.premiumActive = !!st.active;
    if (d.limits) state.limits = d.limits;
    applyPremiumLook();
    syncPremiumGates();
    const badge = $("premiumBadge");
    if (st.active) {
      const left = formatPremiumLeft(st);
      const until = formatPremiumExpiry(st);
      badge.textContent = "★ Premium active — " + left;
      badge.className = "premium-badge active";
      $("premiumStatusTitle").textContent = "You're Premium!";
      $("premiumStatusText").textContent = until
        ? ("Thank you for supporting Efadro. Countdown ends " + until + ".")
        : "Thank you for supporting Efadro.";
      $("premiumBtn").classList.add("premium-active");
    } else {
      badge.textContent = "Not subscribed";
      badge.className = "premium-badge inactive";
      $("premiumStatusTitle").textContent = "Support Efadro";
      $("premiumStatusText").textContent = "Buy in Telegram via CryptoBot. The countdown starts only after you activate the code here.";
      $("premiumBtn").classList.remove("premium-active");
    }
    const plans = d.plans || [];
    $("premiumPlans").innerHTML = plans.map(p => `
      <div class="plan-card" data-plan="${escapeHtml(p.id)}">
        <div class="plan-name">${escapeHtml(p.name.replace("Efadro Premium — ", ""))}</div>
        <div class="plan-days">${p.days} days</div>
        <span class="plan-price">${escapeHtml(p.symbol || "$")}${p.price}<small>${escapeHtml(p.currency || "USD")}</small></span>
      </div>`).join("");
    const bot = d.bot || {};
    const openBtn = $("openTelegramBot");
    if (bot.url) {
      openBtn.href = bot.url;
      openBtn.classList.remove("disabled");
      openBtn.textContent = bot.username ? ("Open @" + bot.username) : "Open Telegram bot";
    } else {
      openBtn.removeAttribute("href");
      openBtn.classList.add("disabled");
      openBtn.textContent = "Telegram bot is not configured on this server";
    }
    renderActivations(d.activations);
  } catch (e) { toast(e.message, "error"); }
}

function renderActivations(items) {
  const box = $("orderHistory");
  if (!items || !items.length) { box.innerHTML = ""; return; }
  box.innerHTML = `<h5>Activated codes</h5>` + items.map(o => `
    <div class="order-item">
      <span>${escapeHtml(o.activated_at || "")} · ${escapeHtml(o.plan)} (${o.days}d) · ${escapeHtml(o.code || "")}</span>
      <span class="st paid">used</span>
    </div>`).join("");
}

async function activatePremium() {
  const raw = ($("premiumCodeInput").value || "").trim();
  if (!raw) { toast("Enter an activation code", "info"); return; }
  try {
    const d = await api("POST", "/api/premium/activate", { code: raw });
    $("premiumCodeInput").value = "";
    await loadPremiumState();
    const left = formatPremiumLeft(d.status);
    toast("Premium activated" + (left ? " — " + left : "") + "!", "success");
  } catch (e) { toast(e.message, "error"); }
}

/* ---------------- modals ---------------- */
function openModal(id) { $(id).classList.remove("hidden"); }
function closeModal(id) { $(id).classList.add("hidden"); }
function closeAllModals() {
  document.querySelectorAll(".modal-overlay").forEach(m => m.classList.add("hidden"));
  document.querySelectorAll(".lightbox").forEach(m => m.classList.add("hidden"));
}

/* ---------------- logout ---------------- */
function doLogout() {
  try { api("POST", "/api/logout"); } catch (e) { /* noop */ }
  if (state.socket) { try { state.socket.disconnect(); } catch (e) {} }
  ["myUsername", "myDisplayName", "myRole", "myPermissions", "myAvatar"].forEach(k => localStorage.removeItem(k));
  location.href = "../auth/login/";
}

/* ---------------- wire up UI ---------------- */

/* ---------------- extras: polls, stickers, info drawer, search, 2fa ---------- */
let replyTo = null;

function pollHtml(m) {
  const p = m.payload || {};
  const opts = p.options || [];
  const votes = p.votes || {};
  const total = opts.reduce((s, _, i) => s + ((votes[String(i)] || []).length), 0) || 0;
  const rows = opts.map((label, i) => {
    const n = (votes[String(i)] || []).length;
    const pct = total ? Math.round(n / total * 100) : 0;
    const mine = (votes[String(i)] || []).includes(state.me);
    return `<button class="poll-opt" data-poll="${m.id}" data-opt="${i}">${escapeHtml(label)} · ${n}${mine ? " ✓" : ""}<span class="bar" style="width:${pct}%"></span></button>`;
  }).join("");
  return `<div class="bubble poll-card"><div class="poll-q">${escapeHtml(p.question || "Poll")}</div>${rows}</div>`;
}

function openInfoDrawer() {
  const d = $("chatInfoDrawer");
  if (!d) return;
  d.classList.remove("hidden");
  requestAnimationFrame(() => d.classList.add("open"));
}
function closeInfoDrawer() {
  const d = $("chatInfoDrawer");
  if (!d) return;
  d.classList.remove("open");
  setTimeout(() => d.classList.add("hidden"), 280);
}

async function fillInfoMedia() {
  if (!state.currentChat) return;
  try {
    const d = await api("GET", "/api/chats/" + state.currentChat.uuid + "/media");
    const media = $("info-media");
    const links = $("info-links");
    const files = $("info-files");
    if (media) {
      media.innerHTML = (d.media || []).length
        ? `<div class="info-media-grid">${d.media.map(x => {
            const url = fileUrl(x.file_id, x.mime, x.name || x.type);
            if (x.type === "image") return `<img src="${escapeHtml(url)}" alt="">`;
            if (x.type === "video") return `<video src="${escapeHtml(url)}" muted></video>`;
            return `<div class="info-file">${escapeHtml(x.name || x.type)}</div>`;
          }).join("")}</div>`
        : `<p class="cp-hint">No media yet.</p>`;
    }
    if (links) {
      links.innerHTML = (d.links || []).length
        ? d.links.map(x => `<a class="info-link" href="${escapeHtml(x.url)}" target="_blank" rel="noopener">${escapeHtml(x.url)}</a>`).join("")
        : `<p class="cp-hint">No links yet.</p>`;
    }
    if (files) {
      files.innerHTML = (d.files || []).length
        ? d.files.map(x => `<a class="info-file" href="${escapeHtml(fileUrl(x.file_id, x.mime, x.name, true))}" download>${escapeHtml(x.name || "file")}</a>`).join("")
        : `<p class="cp-hint">No files yet.</p>`;
    }
    const pin = $("pinBar");
    if (pin) {
      if (d.pin) {
        pin.classList.remove("hidden");
        pin.textContent = "📌 Pinned message";
        pin.onclick = () => {
          const el = document.querySelector(`.msg-row[data-id="${d.pin}"]`);
          if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
        };
      } else pin.classList.add("hidden");
    }
  } catch (e) { /* ignore */ }
}

function setReply(row) {
  replyTo = { id: row.dataset.id, sender: row.dataset.sender, preview: (row.querySelector(".bubble-text") || row.querySelector(".bubble") || {}).textContent || "" };
  $("replyToName").textContent = replyTo.sender;
  $("replyToText").textContent = (replyTo.preview || "").slice(0, 80);
  $("replyBar").classList.remove("hidden");
  $("messageInput").focus();
}
function clearReply() {
  replyTo = null;
  const bar = $("replyBar");
  if (bar) bar.classList.add("hidden");
}

async function sendPoll() {
  if (!state.currentChat) return;
  const q = ($("pollQuestion").value || "").trim();
  const opts = [1,2,3,4].map(i => ($("pollOpt" + i).value || "").trim()).filter(Boolean);
  if (!q || opts.length < 2) { toast("Need a question and at least two options", "info"); return; }
  try {
    const msg = await api("POST", "/api/send", {
      uuid: state.currentChat.uuid, type: "poll",
      payload: { question: q, options: opts, multiple: $("pollMultiple").checked },
    });
    closeModal("pollModal");
    appendMessageLocal(msg);
  } catch (e) { toast(e.message, "error"); }
}

async function loadStickers() {
  const grid = $("stickerGrid");
  if (!grid || grid.dataset.loaded) return;
  try {
    const d = await api("GET", "/api/stickers");
    const pack = (d.packs || [])[0];
    if (!pack) return;
    grid.innerHTML = pack.stickers.map(s =>
      `<button type="button" class="sticker-cell" data-sticker="${escapeHtml(s.id)}" title="${escapeHtml(s.emoji)}"><img src="stickers/${escapeHtml(s.file)}" alt="${escapeHtml(s.emoji)}"></button>`
    ).join("");
    grid.dataset.loaded = "1";
  } catch (e) { /* ignore */ }
}

async function sendSticker(id) {
  if (!state.currentChat) return;
  try {
    const payload = { pack: "efadro", id };
    if (replyTo) payload.reply_to = replyTo.id;
    const msg = await api("POST", "/api/send", { uuid: state.currentChat.uuid, type: "sticker", payload });
    clearReply();
    appendMessageLocal(msg);
  } catch (e) { toast(e.message, "error"); }
}

async function runChatSearch(q) {
  const box = $("chatSearchHits");
  if (!box || !state.currentChat) return;
  if ((q || "").trim().length < 2) { box.classList.add("hidden"); box.innerHTML = ""; return; }
  try {
    const d = await api("GET", `/api/chats/${state.currentChat.uuid}/search?q=` + encodeURIComponent(q.trim()));
    const hits = d.hits || [];
    box.classList.toggle("hidden", !hits.length);
    box.innerHTML = hits.map(h =>
      `<button type="button" class="search-hit" data-jump="${escapeHtml(h.id)}"><b>${escapeHtml(h.sender)}</b> — ${escapeHtml(h.preview || h.type)}</button>`
    ).join("");
  } catch (e) { box.classList.add("hidden"); }
}

function fillAccountExtras(me) {
  const region = me.region || {};
  const regionText = (region.name && region.name.toLowerCase() !== "unknown")
    ? region.name
    : (region.code && region.code !== "ZZ" ? region.code : "");
  if ($("regionLabel")) $("regionLabel").textContent = regionText || "—";
  if ($("emailLabel")) $("emailLabel").textContent = me.email || "—";
  if ($("emailStatus")) $("emailStatus").textContent = me.email_verified ? "Verified" : (me.email_required ? "Verification required" : (me.email ? "Not verified" : "Not set"));
  const biz = (me.profile && me.profile.business) || {};
  const box = $("businessBox");
  if (box) {
    box.classList.toggle("hidden", !isPremium());
    if ($("bizLocation")) $("bizLocation").value = biz.location || "";
    if ($("bizHours")) $("bizHours").value = biz.hours || "";
  }
  if ($("totpStatus")) $("totpStatus").textContent = me.totp_enabled ? "On — required at sign-in." : "Off";
  if ($("totpDisableBtn")) $("totpDisableBtn").classList.toggle("hidden", !me.totp_enabled);
}

async function setupPush() {
  try {
    const info = await api("GET", "/api/push/vapid");
    if (window.efadroNative && window.efadroNative.platform === "android" && window.efadroOneSignalPlayerId) {
      await api("POST", "/api/push/subscribe", { platform: "android", player_id: window.efadroOneSignalPlayerId });
    }
    if (!info.publicKey || !("serviceWorker" in navigator) || !("PushManager" in window)) return;
    const perm = await Notification.requestPermission();
    if (perm !== "granted") return;
    const reg = await navigator.serviceWorker.register("./sw.js");
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(info.publicKey),
    });
    const raw = sub.toJSON();
    await api("POST", "/api/push/subscribe", {
      endpoint: raw.endpoint, keys: raw.keys, platform: "web",
    });
  } catch (e) { /* optional */ }
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const b64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(b64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}


function wireEvents() {
  // composer
  $("messageInput").addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendText(); }
    emitTyping();
  });
  $("sendBtn").addEventListener("click", sendText);
  $("messageInput").addEventListener("input", () => {
    $("sendBtn").classList.toggle("hidden", !$("messageInput").value.trim());
  });

  // attach
  $("attachBtn").addEventListener("click", e => {
    e.stopPropagation();
    $("attachMenu").classList.toggle("hidden");
    toggleEmojiPicker(false);
  });
  // emoji
  $("emojiBtn").addEventListener("click", e => {
    e.stopPropagation();
    $("attachMenu").classList.add("hidden");
    toggleEmojiPicker();
  });
  document.addEventListener("click", e => {
    $("attachMenu").classList.add("hidden");
    const picker = $("emojiPicker");
    if (picker && !picker.contains(e.target) && e.target.id !== "emojiBtn") {
      toggleEmojiPicker(false);
    }
  });
  $("attachMenu").querySelectorAll("button").forEach(b => {
    b.addEventListener("click", () => {
      if (b.dataset.kind === "poll") { openModal("pollModal"); return; }
      $("fileInput").dataset.kind = b.dataset.kind;
      $("fileInput").click();
    });
  });
  $("fileInput").addEventListener("change", () => {
    const f = $("fileInput").files[0];
    if (f) sendFile($("fileInput").dataset.kind || "file", f);
    $("fileInput").value = "";
  });

  // drag & drop
  $("messagesList").addEventListener("dragover", e => e.preventDefault());
  $("messagesList").addEventListener("drop", e => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f) {
      const kind = f.type.startsWith("image/") ? "image" : f.type.startsWith("audio/") ? "audio" : f.type.startsWith("video/") ? "video" : "file";
      sendFile(kind, f);
    }
  });

  // message actions (delete for me / for everyone)
  async function deleteMessage(row, scope) {
    const id = row.dataset.id;
    try {
      await api("POST", "/api/messages/delete", { id, scope });
      row.remove();
      if (scope === "everyone") {
        const chat = state.chats.find(c => c.uuid === row.dataset.chat);
        if (chat) chat.last_message = null;
        refreshChatPreviews();
      }
    } catch (err) { toast(err.message, "error"); }
  }
  $("messagesList").addEventListener("click", async e => {
    const actBtn = e.target.closest("[data-act=delete]");
    if (actBtn) {
      e.stopPropagation();
      const menu = actBtn.parentElement.querySelector(".del-menu");
      document.querySelectorAll(".del-menu").forEach(m => { if (m !== menu) m.classList.add("hidden"); });
      menu.classList.toggle("hidden");
      return;
    }
    const delSelf = e.target.closest("[data-act=del-self]");
    if (delSelf) { deleteMessage(delSelf.closest(".msg-row"), "self"); return; }
    const delAll = e.target.closest("[data-act=del-everyone]");
    if (delAll) { deleteMessage(delAll.closest(".msg-row"), "everyone"); return; }
    const replyBtn = e.target.closest("[data-act=reply]");
    if (replyBtn) { setReply(replyBtn.closest(".msg-row")); return; }
    const pollBtn = e.target.closest("[data-poll]");
    if (pollBtn) {
      try {
        const d = await api("POST", "/api/polls/vote", { id: pollBtn.dataset.poll, option: Number(pollBtn.dataset.opt) });
        const row = pollBtn.closest(".msg-row");
        const payload = d.payload || d.poll;
        if (row && payload) {
          const fake = { id: pollBtn.dataset.poll, payload, type: "poll" };
          const card = row.querySelector(".poll-card");
          if (card) card.outerHTML = pollHtml(fake);
        }
      } catch (err) { toast(err.message, "error"); }
      return;
    }
    const img = e.target.closest(".msg-image img");
    if (img) openLightbox(img.dataset.src, img.dataset.name);
  });
  // clicking anywhere else closes open delete menus
  document.addEventListener("click", e => {
    if (e.target.closest(".msg-actions")) return;
    document.querySelectorAll(".del-menu").forEach(m => m.classList.add("hidden"));
  });

  // now playing bar (reflects the active custom audio player)
  $("npToggle").addEventListener("click", () => {
    const a = state.activeAudio;
    if (!a) return;
    if (a.paused) playAudio(a, $("npTitle").textContent, $("npSub").textContent);
    else a.pause();
  });
  $("npClose").addEventListener("click", () => {
    if (state.activeAudio) state.activeAudio.pause();
    $("nowPlaying").classList.add("hidden");
  });

  // scroll-to-bottom behaviour
  $("messagesList").addEventListener("scroll", () => {
    updateJumpButton();
  }, { passive: true });
  $("jumpBottom").addEventListener("click", () => {
    const list = $("messagesList");
    list.scrollTo({ top: list.scrollHeight, behavior: "smooth" });
  });

  // lightbox zoom controls
  $("lbZoomIn").addEventListener("click", () => zoomLb(0.25));
  $("lbZoomOut").addEventListener("click", () => zoomLb(-0.25));
  $("lbZoomFit").addEventListener("click", () => {
    lbZoomFactor = 1;
    applyLbZoom();
  });
  $("lbStage").addEventListener("wheel", e => {
    e.preventDefault();
    zoomLb(e.deltaY < 0 ? 0.25 : -0.25);
  }, { passive: false });

  // header buttons
  $("callVoiceBtn").addEventListener("click", () => startCall("voice"));
  $("callVideoBtn").addEventListener("click", () => startCall("video"));
  $("chatInfoBtn").addEventListener("click", async () => { await loadChatInfo(); openInfoDrawer(); });

  // sidebar
  $("newChatBtn").addEventListener("click", openCreateChat);
  $("emptyNewChat").addEventListener("click", openCreateChat);
  ["addStoryBtn", "yourStoryBtn", "emptyNewStory", "mobileStoryBtn"].forEach(id => {
    const el = $(id);
    if (el) el.addEventListener("click", openStoryCompose);
  });
  // search: filter chats instantly + exact-username global lookup (debounced)
  let searchTimer = null;
  $("searchInput").addEventListener("input", () => {
    renderContacts();
    const q = $("searchInput").value.trim();
    clearTimeout(searchTimer);
    if (q.length < 2) {
      state.userMatches = {};
      renderContacts();
      return;
    }
    const key = q.toLowerCase();
    const seq = ++state.searchSeq;
    searchTimer = setTimeout(async () => {
      try {
        const users = await api("GET", "/api/users?q=" + encodeURIComponent(key));
        const hit = (users || []).find(u => u.username.toLowerCase() === key);
        if (seq !== state.searchSeq) return; // stale response
        if (hit) state.userMatches[key] = hit;
        else delete state.userMatches[key];
        renderContacts();
      } catch (e) { /* offline — ignore */ }
    }, 250);
  });
  $("settingsBtn").addEventListener("click", () => openSettings());
  $("premiumBtn").addEventListener("click", openPremium);
  $("logoutBtn").addEventListener("click", () => { if (confirm("Log out?")) doLogout(); });

  // mobile drawer (hamburger next to the logo)
  const menuBtn = $("mobileMenuBtn");
  if (menuBtn) menuBtn.addEventListener("click", toggleDrawer);
  const overlay = $("drawerOverlay");
  if (overlay) overlay.addEventListener("click", closeDrawer);
  const mobileNew = $("mobileNewChatBtn");
  if (mobileNew) mobileNew.addEventListener("click", () => { closeDrawer(); openCreateChat(); });
  const drawerNav = $("drawerNav");
  if (drawerNav) {
    drawerNav.addEventListener("click", e => {
      const item = e.target.closest("[data-drawer]");
      if (!item) return;
      const act = item.dataset.drawer;
      drawerNav.querySelectorAll(".drawer-item").forEach(x => x.classList.toggle("active", x === item));
      if (act === "chats") {
        closeAllModals();
        closeDrawer();
        setCurrentChat(null);
        return;
      }
      if (act === "story") { closeDrawer(); openStoryCompose(); return; }
      if (act === "premium") { closeDrawer(); openPremium(); return; }
      if (act === "cp") { closeDrawer(); openCp(); return; }
      if (act === "logout") { if (confirm("Log out?")) doLogout(); return; }
      closeDrawer();
      openSettings(act);
    });
  }
  const drawerClose = $("settingsDrawerClose");
  if (drawerClose) drawerClose.addEventListener("click", closeDrawer);
  const backBtn = $("chatBackBtn");
  if (backBtn) backBtn.addEventListener("click", () => setCurrentChat(null));
  fitVisualViewport();
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", fitVisualViewport);
    window.visualViewport.addEventListener("scroll", fitVisualViewport);
  }
  window.addEventListener("resize", fitVisualViewport);

  // call buttons
  $("callEndBtn").addEventListener("click", endCall);
  $("callMuteBtn").addEventListener("click", () => {
    const muted = !call.localStream || call.localStream.getAudioTracks()[0].enabled;
    if (call.localStream) call.localStream.getAudioTracks().forEach(t => { t.enabled = muted; });
    $("callMuteBtn").classList.toggle("off", !muted);
  });
  $("callCamBtn").addEventListener("click", () => {
    const v = call.localStream && call.localStream.getVideoTracks()[0];
    if (!v) return;
    v.enabled = !v.enabled;
    $("callCamBtn").classList.toggle("off", !v.enabled);
  });
  $("incomingAcceptBtn").addEventListener("click", acceptIncoming);
  $("incomingRejectBtn").addEventListener("click", () => {
    stopRinging();
    if (state.socket && call.callId) state.socket.emit("reject_call", { call_id: call.callId, to: call.peer });
    $("incomingCall").classList.add("hidden");
    call.callId = null; call.peer = null;
  });

  // modal close buttons
  document.querySelectorAll(".modal-close").forEach(b => {
    b.addEventListener("click", () => closeModal(b.dataset.close));
  });
  document.querySelectorAll(".modal-overlay").forEach(ov => {
    ov.addEventListener("mousedown", e => {
      if (e.target === ov) ov.classList.add("hidden");
    });
  });
  $("lbClose").addEventListener("click", () => $("lightbox").classList.add("hidden"));
  const hideLightbox = () => $("lightbox").classList.add("hidden");
  $("lightbox").addEventListener("click", e => {
    // close when clicking the overlay or the empty stage (not while zoomed in)
    if (e.target === $("lightbox")) hideLightbox();
    if (e.target === $("lbStage") && lbZoomFactor <= 1) hideLightbox();
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && !$("lightbox").classList.contains("hidden")) hideLightbox();
  });

  // create chat (group / channel only)
  document.querySelectorAll("#chatTypeSeg button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll("#chatTypeSeg button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
    });
  });
  $("memberSearch").addEventListener("input", e => renderPicker(e.target.value.trim().toLowerCase()));
  $("createChatBtn").addEventListener("click", createChat);

  // settings
  document.querySelectorAll(".settings-tabs button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll(".settings-tabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      document.querySelectorAll(".settings-pane").forEach(p => p.classList.remove("active"));
      $("pane-" + b.dataset.tab).classList.add("active");
    });
  });
  document.querySelectorAll("#themeSeg button").forEach(b => {
    b.addEventListener("click", () => {
      const dark = b.dataset.theme === "dark";
      document.documentElement.classList.toggle("dark", dark);
      localStorage.setItem("efadro-theme", dark ? "dark" : "light");
      document.querySelectorAll("#themeSeg button").forEach(x => x.classList.toggle("active", x === b));
    });
  });
  document.querySelectorAll("#radiusSeg button").forEach(b => {
    b.addEventListener("click", () => {
      document.documentElement.style.setProperty("--msg-radius", b.dataset.r + "px");
      localStorage.setItem("efadro-msg-radius", b.dataset.r);
      document.querySelectorAll("#radiusSeg button").forEach(x => x.classList.toggle("active", x === b));
    });
  });
  $("settingsSwatches").addEventListener("click", e => {
    const sw = e.target.closest(".swatch");
    if (!sw) return;
    document.documentElement.style.setProperty("--accent", sw.dataset.color);
    localStorage.setItem("efadro-accent", sw.dataset.color);
    document.querySelectorAll(".swatch").forEach(s => s.classList.toggle("active", s === sw));
  });
  const mineEl = $("bubbleMine");
  if (mineEl) mineEl.addEventListener("input", () => {
    if (!isPremium()) return;
    localStorage.setItem("efadro-bubble-mine", mineEl.value);
    applyPremiumLook();
  });
  const theirsEl = $("bubbleTheirs");
  if (theirsEl) theirsEl.addEventListener("input", () => {
    if (!isPremium()) return;
    localStorage.setItem("efadro-bubble-theirs", theirsEl.value);
    applyPremiumLook();
  });
  document.querySelectorAll("#fontSeg button").forEach(b => {
    b.addEventListener("click", () => {
      if (!isPremium()) { openPremium(); return; }
      localStorage.setItem("efadro-msg-font", b.dataset.fs);
      document.querySelectorAll("#fontSeg button").forEach(x => x.classList.toggle("active", x === b));
      applyPremiumLook();
    });
  });
  const compactEl = $("compactChats");
  if (compactEl) compactEl.addEventListener("change", () => {
    if (!isPremium()) { compactEl.checked = false; openPremium(); return; }
    localStorage.setItem("efadro-compact", compactEl.checked ? "1" : "0");
    applyPremiumLook();
  });
  const wpBox = $("wallpaperPresets");
  if (wpBox) wpBox.addEventListener("click", e => {
    const btn = e.target.closest("[data-wp]");
    if (!btn) return;
    if (!isPremium()) { openPremium(); return; }
    const spec = WALLPAPERS.find(w => w.id === btn.dataset.wp);
    if (!spec) return;
    if (spec.css) localStorage.setItem("efadro-wallpaper", spec.css);
    else localStorage.removeItem("efadro-wallpaper");
    localStorage.setItem("efadro-wallpaper-id", spec.id);
    applyPremiumLook();
    syncPremiumLookFields();
  });
  const extrasLink = $("extrasPremiumLink");
  if (extrasLink) extrasLink.addEventListener("click", () => closeModal("settingsModal"));
  const devUp = $("devPremiumUpgrade");
  if (devUp) devUp.addEventListener("click", () => {
    closeModal("settingsModal");
    location.href = "../premium/";
  });
  $("avatarUploadBtn").addEventListener("click", () => $("avatarInput").click());
  $("avatarInput").addEventListener("change", async () => {
    const f = $("avatarInput").files[0];
    if (!f) return;
    const fd = new FormData();
    fd.append("file", f);
    try {
      const r = await fetch(SERVER + "/api/avatar/upload", { method: "POST", headers: { "X-Username": state.me }, credentials: "include", body: fd });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "upload failed");
      localStorage.setItem("myAvatar", d.avatar);
      $("settingsAvatar").innerHTML = `<img src="${escapeHtml(d.avatar)}" alt="">`;
      updateSidebarUser();
      toast("Avatar updated", "success");
    } catch (e) { toast(e.message, "error"); }
  });
  $("avatarRemoveBtn").addEventListener("click", async () => {
    try { await api("POST", "/api/avatar/remove"); localStorage.removeItem("myAvatar"); $("settingsAvatar").textContent = initials(state.me); updateSidebarUser(); toast("Avatar reset", "success"); }
    catch (e) { toast(e.message, "error"); }
  });
  $("saveProfileBtn").addEventListener("click", async () => {
    try {
      const display = $("displayNameInput").value.trim();
      if (/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(display)) {
        toast("Display name cannot contain emoji", "error");
        return;
      }
      const d = await api("POST", "/api/profile", { display_name: display, bio: $("bioInput").value.trim() });
      state.myDisplayName = d.display_name || state.me;
      localStorage.setItem("myDisplayName", state.myDisplayName);
      if (isPremium()) {
        try {
          await api("POST", "/api/business", {
            location: ($("bizLocation") && $("bizLocation").value.trim()) || "",
            hours: ($("bizHours") && $("bizHours").value.trim()) || "",
          });
        } catch (err) { /* optional */ }
      }
      updateSidebarUser();
      renderContacts();
      toast("Profile saved", "success");
    } catch (e) { toast(e.message, "error"); }
  });
  $("changePwBtn").addEventListener("click", async () => {
    try {
      await api("POST", "/api/profile/password", { current_password: $("curPwInput").value, new_password: $("newPwInput").value });
      $("curPwInput").value = ""; $("newPwInput").value = "";
      toast("Password changed", "success");
    } catch (e) { toast(e.message, "error"); }
  });

  // developer (API login)
  $("devCreateBtn").addEventListener("click", createDevApp);
  $("devAppsList").addEventListener("click", e => {
    const btn = e.target.closest("[data-dev]");
    if (!btn) return;
    const cid = btn.dataset.cid;
    if (btn.dataset.dev === "copy-cid") copyText(cid, "Client ID copied");
    else if (btn.dataset.dev === "key") regenerateDevKey(cid);
    else if (btn.dataset.dev === "del") deleteDevApp(cid);
  });
  $("devSecretBox").addEventListener("click", e => {
    const btn = e.target.closest("[data-secret]");
    if (!btn) return;
    copyText(btn.dataset.val, btn.textContent + " copied");
  });

  // control panel
  $("cpBtn").addEventListener("click", openCp);
  document.querySelectorAll(".cp-tabs button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll(".cp-tabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      document.querySelectorAll(".cp-pane").forEach(p => p.classList.remove("active"));
      $("cp-" + b.dataset.cptab).classList.add("active");
    });
  });
  $("cpCreateUserBtn").addEventListener("click", () => {
    const name = prompt("Username:");
    if (!name) return;
    const pw = prompt("Password:");
    if (!pw) return;
    api("POST", "/api/cp/users/create", { username: name, password: pw, role: "user" })
      .then(() => { toast("User created", "success"); loadCpUsers(); loadCpStats(); })
      .catch(e => toast(e.message, "error"));
  });
  $("rolesSaveBtn").addEventListener("click", async () => {
    if (!$("rolesRaw").classList.contains("hidden")) {
      try {
        await api("POST", "/api/cp/roles", { raw: $("rolesRaw").value });
        toast("Roles saved", "success");
        loadCpRoles();
      } catch (e) { toast(e.message, "error"); }
      return;
    }
    try {
      await api("POST", "/api/cp/roles", { roles: cpRoles });
      toast("Roles saved", "success");
      loadCpRoles();
    } catch (e) { toast(e.message, "error"); }
  });
  $("rolesRawToggle").addEventListener("click", () => {
    $("rolesRaw").classList.toggle("hidden");
    $("rolesMatrix").classList.toggle("hidden");
    $("rolesRawToggle").textContent = $("rolesRaw").classList.contains("hidden") ? "Raw editor" : "Matrix view";
  });
  $("blacklistAddBtn").addEventListener("click", async () => {
    const ip = $("blacklistIp").value.trim();
    if (!ip) return;
    try { await api("POST", "/api/cp/blacklist", { ip }); $("blacklistIp").value = ""; loadCpBlacklist(); toast("IP blocked", "success"); }
    catch (e) { toast(e.message, "error"); }
  });
  $("broadcastBtn").addEventListener("click", async () => {
    const text = $("broadcastText").value.trim();
    if (!text) return;
    try { await api("POST", "/api/cp/broadcast", { text }); $("broadcastText").value = ""; toast("Broadcast sent", "success"); }
    catch (e) { toast(e.message, "error"); }
  });

  // premium
  $("activatePremiumBtn").addEventListener("click", activatePremium);
  $("premiumCodeInput").addEventListener("keydown", e => {
    if (e.key === "Enter") { e.preventDefault(); activatePremium(); }
  });

  // stories
  const sc = $("sidebarChats");
  if (sc) sc.addEventListener("scroll", updateStoriesCollapse, { passive: true });
  document.querySelectorAll("#storyKindSeg button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll("#storyKindSeg button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      $("storyFileInput").accept = storyKindAccept(b.dataset.kind);
    });
  });
  $("storyPostBtn").addEventListener("click", postStory);
  $("storyClose").addEventListener("click", closeStoryViewer);
  $("storyPrev").addEventListener("click", () => { storyView.ii -= 1; showStoryItem(); });
  $("storyNext").addEventListener("click", () => { storyView.ii += 1; showStoryItem(); });
  document.addEventListener("keydown", e => {
    if ($("storyViewer").classList.contains("hidden")) return;
    if (e.key === "Escape") closeStoryViewer();
    if (e.key === "ArrowRight") { storyView.ii += 1; showStoryItem(); }
    if (e.key === "ArrowLeft") { storyView.ii -= 1; showStoryItem(); }
  });

  // broadcast banner
  $("broadcastClose").addEventListener("click", () => $("broadcastBanner").classList.add("hidden"));

  // cross-tab theme sync
  window.addEventListener("storage", e => {
    if (e.key === "efadro-theme") document.documentElement.classList.toggle("dark", e.newValue === "dark");
    else if (e.key === "efadro-accent" && e.newValue) document.documentElement.style.setProperty("--accent", e.newValue);
  });

  const infoClose = $("infoDrawerClose");
  if (infoClose) infoClose.addEventListener("click", closeInfoDrawer);
  document.querySelectorAll("#infoTabs button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll("#infoTabs button").forEach(x => x.classList.toggle("active", x === b));
      document.querySelectorAll(".info-pane").forEach(p => p.classList.toggle("active", p.id === "info-" + b.dataset.infotab));
    });
  });
  const searchBtn = $("chatSearchBtn");
  if (searchBtn) searchBtn.addEventListener("click", () => {
    $("chatSearchBar").classList.toggle("hidden");
    $("chatSearchInput").focus();
  });
  const searchClose = $("chatSearchClose");
  if (searchClose) searchClose.addEventListener("click", () => {
    $("chatSearchBar").classList.add("hidden");
    $("chatSearchHits").classList.add("hidden");
  });
  const searchInput = $("chatSearchInput");
  if (searchInput) searchInput.addEventListener("input", () => runChatSearch(searchInput.value));
  const hits = $("chatSearchHits");
  if (hits) hits.addEventListener("click", e => {
    const b = e.target.closest("[data-jump]");
    if (!b) return;
    const el = document.querySelector(`.msg-row[data-id="${b.dataset.jump}"]`);
    if (el) { el.scrollIntoView({ behavior: "smooth", block: "center" }); el.classList.add("highlight"); setTimeout(() => el.classList.remove("highlight"), 1600); }
  });
  const stickerBtn = $("stickerBtn");
  if (stickerBtn) stickerBtn.addEventListener("click", async () => {
    await loadStickers();
    $("stickerPicker").classList.toggle("hidden");
    $("emojiPicker").classList.add("hidden");
  });
  const stickerGrid = $("stickerGrid");
  if (stickerGrid) stickerGrid.addEventListener("click", e => {
    const b = e.target.closest("[data-sticker]");
    if (!b) return;
    $("stickerPicker").classList.add("hidden");
    sendSticker(b.dataset.sticker);
  });
  const pollSend = $("pollSendBtn");
  if (pollSend) pollSend.addEventListener("click", sendPoll);
  const replyCancel = $("replyCancel");
  if (replyCancel) replyCancel.addEventListener("click", clearReply);
  const totpSetup = $("totpSetupBtn");
  if (totpSetup) totpSetup.addEventListener("click", async () => {
    try {
      const d = await api("POST", "/api/2fa/setup", {});
      $("totpSecret").textContent = d.secret;
      $("totpSetupBox").classList.remove("hidden");
      $("totpEnableBtn").classList.remove("hidden");
    } catch (e) { toast(e.message, "error"); }
  });
  const totpEn = $("totpEnableBtn");
  if (totpEn) totpEn.addEventListener("click", async () => {
    try {
      await api("POST", "/api/2fa/enable", { code: $("totpEnableCode").value.trim() });
      toast("2FA enabled", "success");
      $("totpStatus").textContent = "On — required at sign-in.";
      $("totpDisableBtn").classList.remove("hidden");
    } catch (e) { toast(e.message, "error"); }
  });
  const totpDis = $("totpDisableBtn");
  if (totpDis) totpDis.addEventListener("click", async () => {
    const code = prompt("Authenticator code to disable 2FA:");
    if (!code) return;
    try {
      await api("POST", "/api/2fa/disable", { code: code.trim() });
      toast("2FA disabled", "success");
      $("totpStatus").textContent = "Off";
      totpDis.classList.add("hidden");
    } catch (e) { toast(e.message, "error"); }
  });
}



function toggleCpButton() {
  const show = can("view_cp") ? "" : "none";
  if ($("cpBtn")) $("cpBtn").style.display = show;
  if ($("drawerCpBtn")) $("drawerCpBtn").style.display = show;
}

/* ---------------- init ---------------- */
async function init() {
  if (!state.me) {
    location.href = "../auth/login/";
    return;
  }
  wireEvents();
  setComposerState(); // composer always visible, disabled until a chat opens
  toggleCpButton();
  updateSidebarUser();
  $("emptyGreeting").textContent = "Welcome, " + (state.myDisplayName || state.me) + ". Select a conversation, or start a new one.";

  try {
    SERVER = await resolveServerUrl();
  } catch (e) {
    toast("Could not resolve server address", "error");
    return;
  }

  try {
    await e2ee.ensureKeys();
  } catch (e) {
    toast("This browser does not support Web Crypto — E2EE disabled", "error");
  }

  try {
    const io = await loadSocketIO(SERVER);
    socketConnect(io);
  } catch (e) {
    toast(e.message, "error");
  }

  try {
    await ensureFileToken();
    const me = await api("GET", "/api/me");
    if (me.email_required && !me.email_verified) {
      location.href = "../auth/verify/";
      return;
    }
    fillAccountExtras(me);
    await loadChats();
    await loadPremiumState();
    await loadStories();
    setupPush();
  } catch (e) {
    if (e.status === 401) { doLogout(); return; }
    if (e.status === 403 && /email/i.test(e.message || "")) {
      location.href = "../auth/verify/";
      return;
    }
    toast("Backend unreachable at " + SERVER + " — check serverip.txt", "error");
  }
}

document.addEventListener("DOMContentLoaded", init);
